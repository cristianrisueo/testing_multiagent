# Generative AI Agent Manager

Sistema de gestión para levantar agentes de inteligencia generativa como microservicios independientes.

## Descripción

Este proyecto permite lanzar, monitorizar y gestionar múltiples agentes de IA generativa como servicios web independientes. Cada agente se ejecuta en su propio puerto y puede ser controlado individualmente.

## Características

- 🚀 Levantamiento dinámico de agentes como microservicios
- 🔌 Asignación automática de puertos (8001-12001)
- 📋 Catálogo configurable de agentes disponibles
- 🔍 Monitorización de agentes en ejecución
- 🛑 Apagado controlado de servicios
- 🔄 API RESTful para gestión completa
- 🧩 Agente orquestador para centralizar información
- 🔁 Reutilización inteligente de puertos
- 📊 Sistema de logging centralizado y configurable
- 🔒 Manejo robusto de errores y validaciones
- 🧪 Cobertura de tests completa para validación funcional

## Requisitos

- Python 3.8+
- FastAPI
- Uvicorn
- Pydantic
- Psutil
- Requests
- Loguru
- Pytest (para tests)

## Instalación

1. Clonar el repositorio:

   ```bash
   git clone https://github.com/tu-usuario/generative-ai-agent-manager.git
   cd generative-ai-agent-manager
   ```

2. Instalar dependencias:

   ```bash
   pip install -r requirements.txt
   ```

3. Instalar pydantic-settings (para Pydantic v2):
   ```bash
   pip install pydantic-settings
   ```

## Estructura del Proyecto

```
src/
├── main.py               # Punto de entrada de la aplicación
├── api.py                # Endpoints REST
├── models.py             # Modelos de datos
├── services.py           # Lógica de servicios
├── config.py             # Configuración y sistema de logging
├── utils.py              # Utilidades
tests/
├── test_api.py           # Tests para los endpoints REST
├── test_main.py          # Tests para el punto de entrada
├── test_services.py      # Tests para servicios y lógica de negocio
agents_template/
├── main_agente.py        # Código base de agentes regulares
└── main_orquestador.py   # Código base del agente orquestador
data/
└── agents                # Lista de agentes disponibles
agents/
├── vfs/                  # Carpeta para el agente vfs
├── kendra/               # Carpeta para el agente kendra
└── orquestador/          # Carpeta para el agente orquestador
logs/                     # Logs centralizados del sistema
temp/                     # Archivos temporales generados
```

### Descripción de los componentes principales

#### `main.py`

Punto de entrada de la aplicación que inicializa el servidor FastAPI principal. Configura el ciclo de vida de la aplicación, registra las rutas de la API, y gestiona los eventos de inicio y cierre. Implementa un manejador asíncrono (`lifespan`) que garantiza la correcta inicialización de recursos y la limpieza al finalizar.

#### `config.py`

Gestiona toda la configuración centralizada usando `BaseSettings` de Pydantic. Define parámetros como puertos, rutas de archivos, timeouts y nombres de aplicación. Configura también el sistema de logging centralizado usando Loguru, estableciendo formatos, niveles y destinos para los logs. Permite la carga de configuración desde variables de entorno o un archivo `.env`, siguiendo el principio de configuración externalizada.

#### `models.py`

Define los modelos de datos y esquemas utilizando Pydantic, incluyendo:

- Excepciones personalizadas para el manejo de errores
- Payloads para peticiones API (ManifestPayload)
- Respuestas API estandarizadas
- Enumeradores para estados de agentes
- Modelos para información de agentes activos
- Funciones para convertir excepciones en respuestas HTTP

#### `api.py`

Implementa los endpoints REST para interactuar con los agentes. Las rutas incluyen:

- Lanzamiento de agentes (`/launch_agents`)
- Listado de agentes en ejecución (`/list_agents`)
- Detención de agentes (`/stop_agent`)
  
Gestiona la validación de entradas, transformación de excepciones en respuestas HTTP y el enrutamiento general de la API. Incluye tipado explícito de retorno para mejorar la documentación del código.

#### `services.py`

Contiene la lógica de negocio principal con dos clases fundamentales:

- `AgentService`: Gestiona operaciones de bajo nivel para iniciar y detener procesos de agentes individuales
- `AgentManager`: Orquesta múltiples agentes, manteniendo registro de su estado, asignando puertos y coordinando operaciones

#### `utils.py`

Proporciona funciones auxiliares para:

- Manejo de archivos y directorios
- Lectura del catálogo de agentes disponibles
- Generación de archivos de servicio para agentes a partir de plantillas
- Limpieza de archivos temporales

## Tests y Validación

El proyecto incluye una extensa suite de tests automatizados para garantizar la correcta funcionalidad de todos los componentes. La cobertura total supera el 75%, verificando todos los flujos críticos.

### Tipos de Tests

- **Tests de API**: Verifican que los endpoints responden correctamente con diferentes payloads
- **Tests de Servicios**: Validan la lógica de negocio interna
- **Tests de Ciclo de Vida**: Comprueban el inicio y cierre controlado de la aplicación
- **Tests de Manejo de Errores**: Aseguran que los errores se manejan adecuadamente
- **Tests de Manifiestos**: Validan el almacenamiento y recuperación de configuraciones de agentes

### Tests de Manifiestos

Los tests de manifiestos validan específicamente:

- Formato correcto de manifiestos
- Validación de estructura de recursos
- Priorización correcta de recursos específicos sobre globales
- Almacenamiento y limpieza de archivos de configuración
- Manejo de formatos inválidos y casos de error

### Ejecución de Tests

Para ejecutar todos los tests:

```bash
python -m pytest
```

Para ejecutar tests con cobertura:

```bash
python -m pytest --cov=src
```

Para ejecutar un archivo de test específico:

```bash
python -m pytest tests/test_api.py
```

### Cobertura de Tests

La cobertura actual del proyecto es:

| Módulo      | Cobertura |
|-------------|-----------|
| api.py      | 93%       |
| config.py   | 100%      |
| main.py     | 100%      |
| models.py   | 93%       |
| services.py | 77%       |
| utils.py    | 62%       |
| **TOTAL**   | **80%**   |

## Sistema de Logging

El proyecto implementa un sistema de logging centralizado usando Loguru con las siguientes características:

- **Configuración centralizada**: Toda la configuración de logging se realiza en `config.py`
- **Niveles de log**: Soporte para diferentes niveles (debug, info, warning, error, critical)
- **Logs en consola**: Salida formateada y colorizada para facilitar la lectura
- **Logs en archivos**: Almacenamiento automático en archivos con rotación y compresión
- **Rotación automática**: Gestión inteligente del tamaño de los archivos de log
- **Retención configurable**: Limpieza automática de logs antiguos
- **Contexto enriquecido**: Inclusión automática de información como timestamps, niveles y código fuente
- **Integración con FastAPI**: Captura de logs generados por el framework

### Configuración de Logging

El nivel de log puede configurarse mediante la variable de entorno `LOG_LEVEL`. Los valores posibles son:
- `DEBUG`: Información detallada para desarrollo
- `INFO`: Información operativa general (predeterminado)
- `WARNING`: Situaciones problemáticas pero no críticas
- `ERROR`: Errores que impiden funcionalidad
- `CRITICAL`: Errores críticos que requieren atención inmediata

```bash
# Ejemplo: establecer nivel de log a DEBUG
export LOG_LEVEL=DEBUG
```

## Manejo de Errores y Validaciones

El sistema implementa un manejo robusto de errores y validaciones:

- **Excepciones tipadas**: Uso de excepciones específicas para cada tipo de error
- **Conversión de excepciones**: Transformación automática a respuestas HTTP adecuadas
- **Logging automático**: Registro detallado de errores para facilitar diagnóstico
- **Validación con Pydantic**: Validaciones automáticas de esquemas de entrada
- **Mensajes claros**: Respuestas de error informativas para el cliente
- **Tipado explícito**: Especificación clara de tipos de retorno en todos los endpoints

## Configuración

Los agentes disponibles se definen en el archivo `data/agents`. Por defecto incluye:

```
vfs
kendra
llama
gpt4
orquestador
```

Para añadir nuevos agentes, simplemente agregue sus nombres a este archivo.

### Configuración de Logging

En el archivo `.env` o mediante variables de entorno:

```
# Nivel de log (DEBUG, INFO, WARNING, ERROR, CRITICAL)
LOG_LEVEL=INFO

# Formato de los logs (configurado en config.py)
# Por defecto: timestamp colorizado, nivel, módulo:función:línea, mensaje

# Retención de archivos de log
LOG_RETENTION=7 days

# Tamaño de rotación de los archivos de log
LOG_ROTATION=500 MB
```

## Uso

### Iniciar el Servidor

```bash
python main.py
```

El servidor principal estará disponible en http://localhost:8000

### Ejemplos de Uso con curl

Lanzar agentes:

```bash
curl -X POST http://localhost:8000/api/launch_agents \
     -H "Content-Type: application/json" \
     -d '{"agents": ["vfs", "kendra"], "resources": {}}'
```

Listar agentes en ejecución:

```bash
curl http://localhost:8000/api/list_agents
```

Detener un agente por nombre:

```bash
curl -X POST http://localhost:8000/api/stop_agent?agent_name=vfs
```

Consultar información de manifiestos a través del orquestador:

```bash
curl http://localhost:8001/manifests
```

## API Reference

### Servidor Principal (Puerto 8000)

| Endpoint             | Método | Descripción                                       | Tipo de Retorno                    |
| -------------------- | ------ | ------------------------------------------------- | ---------------------------------- |
| `/api/launch_agents` | POST   | Lanza uno o más agentes                           | `Dict[str, list[AgentResponse]]`   |
| `/api/list_agents`   | GET    | Lista agentes en ejecución con filtros opcionales | `Dict[str, list[AgentResponse]]`   |
| `/api/stop_agent`    | POST   | Detiene uno o más agentes                         | `Dict[str, list[AgentResponse]]`   |

### Servicios de Agente Regular (Puertos 8002-12001)

| Endpoint    | Método | Descripción                   |
| ----------- | ------ | ----------------------------- |
| `/`         | GET    | Información básica del agente |
| `/status`   | GET    | Estado detallado del agente   |
| `/shutdown` | GET    | Inicia apagado controlado     |

### Agente Orquestador (Puerto 8001)

| Endpoint     | Método | Descripción                                  |
| ------------ | ------ | -------------------------------------------- |
| `/`          | GET    | Información básica del orquestador           |
| `/status`    | GET    | Estado detallado del orquestador             |
| `/resources` | GET    | Recursos asignados al orquestador            |
| `/manifests` | GET    | Manifiestos de todos los agentes desplegados |
| `/prompt`    | POST   | Procesa un mensaje de prompt                 |
| `/shutdown`  | GET    | Inicia apagado controlado                    |

## Características Adicionales

### Agente Orquestador

El sistema implementa un agente especial "orquestador" que:

- Se inicia automáticamente cuando se lanza el primer agente regular
- Centraliza información sobre todos los agentes en ejecución
- Proporciona endpoints para consultar manifiestos y realizar otras operaciones
- Se detiene automáticamente cuando no hay agentes regulares en ejecución
- Tiene asignado siempre el puerto fijo 8001

### Gestión Eficiente de Puertos

- Reutilización inteligente de puertos: cuando un agente se detiene, su puerto queda disponible para futuros agentes
- Los puertos se asignan de manera secuencial, priorizando los de menor número
- El sistema mantiene un registro de puertos liberados para su reutilización

### Sistema de Logging Centralizado

- Todos los logs se capturan en un único sistema centralizado
- Los agentes y el sistema principal comparten el mismo formato y configuración
- Los logs se almacenan en archivos con rotación automática
- Se proporciona un formato claro y consistente para facilitar el diagnóstico

## Desarrollo

### Extender Funcionalidad de Agentes

Para añadir funcionalidades a los agentes, modifique la plantilla en `agents_template/main.py`. Puede añadir nuevos endpoints o lógica específica para cada tipo de agente.

Para personalizar el agente orquestador, modifique la plantilla en `agents_template/main_orquestador.py`.

### Estructura modular

El proyecto sigue un diseño modular que separa claramente:

- Configuración (`config.py`)
- Modelos de datos (`models.py`)
- Lógica de negocio (`services.py`)
- API REST (`api.py`)
- Utilidades (`utils.py`)
- Tests (`tests/`)

Esta separación permite una fácil extensión y mantenimiento.

### Mejores Prácticas de Logging

Para aprovechar el sistema de logging:

- Use el nivel apropiado para cada mensaje:
  - `logger.debug()`: Información detallada para desarrollo
  - `logger.info()`: Eventos operativos normales
  - `logger.warning()`: Situaciones problemáticas pero recuperables
  - `logger.error()`: Errores que afectan la funcionalidad
  - `logger.critical()`: Errores graves que requieren atención inmediata
- Incluya contexto suficiente en cada mensaje
- Capture y registre excepciones con `logger.exception()`

### Manejo de Errores y Validaciones

Para contribuir al proyecto siguiendo las mejores prácticas de manejo de errores:

- Cree excepciones personalizadas para cada tipo específico de error
- Use bloques try/except con excepciones específicas en lugar de genéricas
- Valide entradas con modelos Pydantic y validadores personalizados
- Asegúrese de que todos los errores se registren con el nivel apropiado
- Proporcione mensajes de error claros y útiles
- Especifique tipos de retorno en todas las funciones

### Desarrollo de Tests

Para mantener la alta calidad del código:

- Escriba tests para cada nueva funcionalidad
- Asegúrese de probar tanto los casos de éxito como los de error
- Use mocks para aislar las partes del sistema que está probando
- Mantenga la cobertura de tests por encima del 70%
- Ejecute los tests regularmente durante el desarrollo

## Casos de Uso

- **Orquestación de múltiples LLMs**: Gestione varios modelos de lenguaje con diferentes capacidades
- **Procesamiento distribuido**: Divida tareas complejas entre múltiples agentes especializados
- **Entornos de prueba**: Compare el rendimiento de diferentes agentes en tiempo real
- **Sistemas escalables**: Añada o elimine capacidades dinámicamente según la demanda
- **Centralización de información**: Use el agente orquestador como punto central para consultar el estado del sistema
