from fastapi import APIRouter, Query, HTTPException
from typing import Optional, Dict
from .config import app_logger as logger
from .models import (
    ManifestPayload,
    AgentListResponse,
    AgentLaunchResponse,
    AgentStopResponse,
    AgentStopRequest,
    AgentException,
    AgentResponse,
    agent_exception_handler,
)
from .services import agent_manager


router = APIRouter()  # Router del API


@router.post("/launch_agents", response_model=AgentLaunchResponse)
async def launch_agents(payload: ManifestPayload) -> Dict[str, list[AgentResponse]]:
    """
    Lanza agentes basados en el manifest

    - Verifica si los agentes solicitados están disponibles
    - Inicia un nuevo servicio para cada agente disponible
    - Devuelve información sobre los agentes lanzados
    """

    try:
        logger.info(f"Solicitando lanzamiento de agentes: {payload.agents}")

        launched_agents = await agent_manager.launch_agents(
            payload.agents, payload.resources
        )

        logger.info(
            f"Agentes lanzados exitosamente: {[a.name for a in launched_agents]}"
        )

        return {"launched_agents": launched_agents}
    except AgentException as exc:
        logger.error(f"Error al lanzar agentes: {exc}")
        raise agent_exception_handler(exc)


@router.post("/stop_agent", response_model=AgentStopResponse)
async def stop_agent(
    request: Optional[AgentStopRequest] = None,
    agent_id: Optional[str] = Query(None),
    agent_name: Optional[str] = Query(None),
    pid: Optional[int] = Query(None),
    port: Optional[int] = Query(None),
) -> Dict[str, list[AgentResponse]]:
    """
    Detiene agentes según los criterios proporcionados

    - Permite detener agentes usando diferentes identificadores
    - Intenta un cierre controlado
    - Devuelve información sobre los agentes detenidos
    """

    # Combina parámetros de query y body. Permite usar ambos
    # y usa el que encuentre empezando por el body
    if request:
        agent_id = request.agent_id or agent_id
        agent_name = request.agent_name or agent_name
        pid = request.pid or pid
        port = request.port or port

    # Registrar la solicitud de detención
    criteria = ", ".join(
        filter(
            None,
            [
                f"agent_id={agent_id}" if agent_id else None,
                f"agent_name={agent_name}" if agent_name else None,
                f"pid={pid}" if pid else None,
                f"port={port}" if port else None,
            ],
        )
    )
    logger.info(f"Solicitando detención de agente(s) con criterios: {criteria}")

    # Detiene los agentes y devuelve una lista con los agentes detenidos
    # o una excepción de error. Aclaración: Agente == Micro
    try:
        stopped_agents = await agent_manager.stop_agent(
            agent_id=agent_id, agent_name=agent_name, pid=pid, port=port
        )

        logger.info(
            f"Agentes detenidos exitosamente: {[a.name for a in stopped_agents]}"
        )

        return {"stopped_agents": stopped_agents}
    except AgentException as exc:
        logger.error(f"Error al detener agente(s): {exc}")
        raise agent_exception_handler(exc)


@router.get("/list_agents", response_model=AgentListResponse)
async def list_agents(
    status: Optional[str] = Query(
        None,
        description="Filtrar por estado (running, starting, stopping, stopped, error)",
    ),
    agent_name: Optional[str] = Query(None, description="Filtrar por nombre de agente"),
) -> Dict[str, list[AgentResponse]]:
    """
    Lista agentes con filtros opcionales

    - Permite filtrar por estado o nombre
    - Devuelve información completa sobre los agentes
    """

    # Registra la solicitud de listado
    filters = ", ".join(
        filter(
            None,
            [
                f"status={status}" if status else None,
                f"agent_name={agent_name}" if agent_name else None,
            ],
        )
    )
    logger.debug(f"Solicitando listado de agentes con filtros: {filters or 'ninguno'}")

    # Busca al agente por nombre o estado
    try:
        agents = agent_manager.list_agents(status=status, agent_name=agent_name)

        logger.debug(
            f"Se encontraron {len(agents)} agentes que coinciden con los filtros"
        )

        return {"agents": agents}
    except Exception as e:
        logger.error(f"Error al listar agentes: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
