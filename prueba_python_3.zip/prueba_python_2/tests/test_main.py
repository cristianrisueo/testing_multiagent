"""
Tests para el fichero main de la aplicación.

Este archivo contiene pruebas unitarias para verificar:
- El funcionamiento del endpoint raíz
- El ciclo de vida de la aplicación (inicio y cierre)
- La configuración básica de la aplicación
"""

import pytest
from fastapi.testclient import TestClient
from src.main import app
from src.config import settings


# Cliente de prueba para la API
client = TestClient(app)


def test_read_root():
    """
    Test para el endpoint raíz de la aplicación.

    Verifica que el endpoint raíz responda correctamente y devuelva
    la información básica de la API incluyendo nombre, descripción
    y endpoints disponibles.
    """

    # Realiza una solicitud GET a la raíz de la API
    response = client.get("/")

    # Verifica que el código de respuesta sea 200 (OK)
    assert response.status_code == 200

    # Verifica que el contenido de la respuesta incluya la información esperada
    data = response.json()
    assert data["app"] == settings.APP_NAME
    assert "description" in data
    assert "endpoints" in data
    assert "launch_agents" in data["endpoints"]
    assert "stop_agent" in data["endpoints"]
    assert "list_agents" in data["endpoints"]


def test_lifespan_startup(monkeypatch):
    """
    Test para verificar las funciones de inicio del ciclo de vida.

    Comprueba que durante el inicio de la aplicación se llamen
    correctamente a las funciones necesarias como ensure_directories.
    """

    # Mock para la función ensure_directories
    called = False

    def mock_ensure_directories():
        nonlocal called
        called = True

    # Reemplaza la función original por la mockeada
    monkeypatch.setattr("src.main.ensure_directories", mock_ensure_directories)

    # Crea un cliente de prueba (esto ejecuta el lifespan startup)
    with TestClient(app) as test_client:
        pass

    # Verifica que se llamó a ensure_directories (se llama en el startup)
    assert called, "La función ensure_directories no fue llamada durante el startup"


@pytest.mark.asyncio
async def test_lifespan_shutdown(monkeypatch):
    """
    Test para verificar las funciones de cierre del ciclo de vida.

    Comprueba que durante el cierre de la aplicación se llamen
    correctamente a las funciones para detener todos los agentes.
    """

    # Mock para el método stop_all_agents
    called = False

    async def mock_stop_all_agents():
        nonlocal called
        called = True
        return []

    # Reemplaza la función original por la mockeada
    monkeypatch.setattr("src.main.agent_manager.stop_all_agents", mock_stop_all_agents)

    # Simula el contexto del lifespan
    async def mock_lifespan_context():
        async with app.router.lifespan_context(app):
            pass

    # Ejecuta el contexto simulado
    await mock_lifespan_context()

    # Verifica que se llamó a stop_all_agents
    assert called, "El método stop_all_agents no fue llamado durante el shutdown"
