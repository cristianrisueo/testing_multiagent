"""
Tests para los endpoints de la API.

Este archivo contiene pruebas unitarias para verificar:
- El funcionamiento de los endpoints de la API
- Las respuestas correctas en casos de éxito
- El manejo adecuado de errores
- El manejo correcto de manifiestos y recursos
"""

import pytest
from unittest.mock import patch, AsyncMock
from fastapi.testclient import TestClient
from src.main import app
from src.models import (
    AgentResponse,
    AgentStatus,
    AgentNotAvailableError,
    AgentNotFoundError,
)


# Cliente de prueba para la API
client = TestClient(app)


@pytest.fixture
def mock_agent_response():
    """
    Fixture que proporciona una respuesta de agente para pruebas.

    Crea un objeto AgentResponse con datos de prueba para usar
    en las verificaciones de los endpoints.
    """
    return AgentResponse(
        id="test-agent-id",
        name="test-agent",
        pid=12345,
        port=8002,
        status=AgentStatus.RUNNING,
        start_time=1234567890.0,
    )


@patch("src.api.agent_manager.launch_agents")
def test_launch_agents_success(mock_launch, mock_agent_response):
    """
    Test para el endpoint de lanzamiento de agentes en caso de éxito.

    Verifica que el endpoint /api/launch_agents responda correctamente
    cuando el lanzamiento de agentes es exitoso.
    """

    # Configura el mock para devolver una lista con un agente
    mock_launch.return_value = [mock_agent_response]

    # Datos para la solicitud
    payload = {"agents": ["test-agent"], "resources": {"test-key": "test-value"}}

    # Realiza la solicitud POST al endpoint
    response = client.post("/api/launch_agents", json=payload)

    # Verifica que el código de respuesta sea 200 (OK)
    assert response.status_code == 200

    # Verifica que la respuesta contenga la información esperada
    data = response.json()
    assert "launched_agents" in data
    assert len(data["launched_agents"]) == 1
    assert data["launched_agents"][0]["name"] == "test-agent"

    # Verifica que se llamó al método launch_agents con los parámetros correctos
    mock_launch.assert_called_once_with(payload["agents"], payload["resources"])


@patch("src.api.agent_manager.launch_agents")
def test_launch_agents_error(mock_launch):
    """
    Test para el endpoint de lanzamiento de agentes en caso de error.

    Verifica que el endpoint /api/launch_agents maneje correctamente
    los errores cuando un agente no está disponible.
    """

    # Configura el mock para lanzar una excepción
    error_msg = "Agente no disponible: unavailable-agent"
    mock_launch.side_effect = AsyncMock(
        side_effect=AgentNotAvailableError("unavailable-agent")
    )

    # Datos para la solicitud
    payload = {"agents": ["unavailable-agent"], "resources": {}}

    # Realiza la solicitud POST al endpoint
    response = client.post("/api/launch_agents", json=payload)

    # Verifica que el código de respuesta sea 400 (Bad Request)
    assert response.status_code == 400

    # Verifica que la respuesta contenga el mensaje de error
    data = response.json()
    assert "detail" in data
    assert data["detail"] == error_msg


@patch("src.api.agent_manager.list_agents")
def test_list_agents_success(mock_list, mock_agent_response):
    """
    Test para el endpoint de listado de agentes.

    Verifica que el endpoint /api/list_agents devuelva correctamente
    la lista de agentes disponibles.
    """

    # Configura el mock para devolver una lista con un agente
    mock_list.return_value = [mock_agent_response]

    # Realiza la solicitud GET al endpoint sin añadir filtros
    response = client.get("/api/list_agents")

    # Verifica que el código de respuesta sea 200 (OK)
    assert response.status_code == 200

    # Verifica que la respuesta contenga la información esperada
    data = response.json()
    assert "agents" in data
    assert len(data["agents"]) == 1
    assert data["agents"][0]["name"] == "test-agent"

    # Verifica que se llamó al método list_agents sin añadir filtros
    mock_list.assert_called_once_with(status=None, agent_name=None)


@patch("src.api.agent_manager.list_agents")
def test_list_agents_with_filters(mock_list, mock_agent_response):
    """
    Test para el endpoint de listado de agentes con filtros.

    Verifica que el endpoint /api/list_agents aplique correctamente
    los filtros por estado y nombre de agente.
    """

    # Configura el mock para devolver una lista con un agente
    mock_list.return_value = [mock_agent_response]

    # Realiza la solicitud GET al endpoint con filtros de estado y nombre
    response = client.get("/api/list_agents?status=running&agent_name=test-agent")

    # Verifica que el código de respuesta sea 200 (OK)
    assert response.status_code == 200

    # Verifica que se llamó al método list_agents con los filtros correctos
    mock_list.assert_called_once_with(status="running", agent_name="test-agent")


@patch("src.api.agent_manager.stop_agent")
def test_stop_agent_by_id_success(mock_stop, mock_agent_response):
    """
    Test para el endpoint de detención de agentes por ID.

    Verifica que el endpoint /api/stop_agent responda correctamente
    cuando se solicita detener un agente por su ID.
    """

    # Configura el mock para devolver una lista con un agente
    mock_stop.return_value = [mock_agent_response]

    # Datos para la solicitud
    payload = {"agent_id": "test-agent-id"}

    # Realiza la solicitud POST al endpoint
    response = client.post("/api/stop_agent", json=payload)

    # Verifica que el código de respuesta sea 200 (OK)
    assert response.status_code == 200

    # Verifica que la respuesta contenga la información esperada
    data = response.json()
    assert "stopped_agents" in data
    assert len(data["stopped_agents"]) == 1
    assert data["stopped_agents"][0]["name"] == "test-agent"

    # Verifica que se llamó al método stop_agent con los parámetros correctos
    mock_stop.assert_called_once_with(
        agent_id="test-agent-id", agent_name=None, pid=None, port=None
    )


@patch("src.api.agent_manager.stop_agent")
def test_stop_agent_by_query_params(mock_stop, mock_agent_response):
    """
    Test para el endpoint de detención de agentes usando parámetros de query.

    Verifica que el endpoint /api/stop_agent responda correctamente
    cuando se solicita detener un agente usando parámetros de query.
    """

    # Configura el mock para devolver una lista con un agente
    mock_stop.return_value = AsyncMock(return_value=[mock_agent_response])

    # Realiza la solicitud POST al endpoint con parámetros de query nombre de
    # agente y puerto (sólo usará el primero al ser varios, pero buena prueba es)
    response = client.post("/api/stop_agent?agent_name=test-agent&port=8002")

    # Verifica que el código de respuesta sea 200 (OK)
    assert response.status_code == 200

    # Verifica que se llamó al método stop_agent con los parámetros correctos
    mock_stop.assert_called_once_with(
        agent_id=None, agent_name="test-agent", pid=None, port=8002
    )


@patch("src.api.agent_manager.stop_agent")
def test_stop_agent_not_found(mock_stop):
    """
    Test para el endpoint de detención de agentes cuando el agente no existe.

    Verifica que el endpoint /api/stop_agent maneje correctamente
    los errores cuando no se encuentra el agente solicitado.
    """

    # Configura el mock para lanzar una excepción
    error_msg = (
        "No se encontraron agentes que coincidan con los criterios: id=nonexistent-id"
    )

    mock_stop.side_effect = AsyncMock(
        side_effect=AgentNotFoundError("id=nonexistent-id")
    )

    # Datos para la solicitud
    payload = {"agent_id": "nonexistent-id"}

    # Realiza la solicitud POST al endpoint con un agente inexistente
    response = client.post("/api/stop_agent", json=payload)

    # Verifica que el código de respuesta sea 404 (Not Found)
    assert response.status_code == 404

    # Verifica que la respuesta contenga el mensaje de error
    data = response.json()
    assert "detail" in data
    assert data["detail"] == error_msg


# Nuevas pruebas para validación de manifiestos y recursos


@patch("src.api.agent_manager.launch_agents")
def test_launch_agents_invalid_manifest_format(mock_launch):
    """
    Test para verificar que el endpoint rechaza manifiestos con formato incorrecto.

    Verifica que el endpoint /api/launch_agents devuelva un error cuando
    se envía un manifiesto con el formato incorrecto.
    """

    # Payload incorrecto: agents debe ser una lista, no un string
    payload = {"agents": "not-a-list", "resources": {"test-key": "test-value"}}

    # Realiza la solicitud POST al endpoint
    response = client.post("/api/launch_agents", json=payload)

    # Verifica que el código de respuesta sea 422 (Unprocessable Entity)
    assert response.status_code == 422

    # Verifica que no se llamó a launch_agents con los parámetros incorrectos
    mock_launch.assert_not_called()


@patch("src.api.agent_manager.launch_agents")
def test_launch_agents_invalid_resources_format(mock_launch):
    """
    Test para verificar que el endpoint rechaza recursos con formato incorrecto.

    Verifica que el endpoint /api/launch_agents devuelva un error cuando
    se envían recursos con formato incorrecto.
    """
    # Payload incorrecto: resources debe ser un diccionario, no una lista
    payload = {"agents": ["test-agent"], "resources": ["not-a-dict"]}

    # Realiza la solicitud POST al endpoint
    response = client.post("/api/launch_agents", json=payload)

    # Verifica que el código de respuesta sea 422 (Unprocessable Entity)
    assert response.status_code == 422

    # Verifica que no se llamó a launch_agents con los parámetros incorrectos
    mock_launch.assert_not_called()


@patch("src.api.agent_manager.launch_agents")
def test_launch_agents_missing_required_field(mock_launch):
    """
    Test para verificar que el endpoint rechaza manifiestos sin campos requeridos.

    Verifica que el endpoint /api/launch_agents devuelva un error cuando
    se envía un manifiesto sin los campos requeridos.
    """
    # Payload incorrecto: falta el campo "agents"
    payload = {"resources": {"test-key": "test-value"}}

    # Realiza la solicitud POST al endpoint
    response = client.post("/api/launch_agents", json=payload)

    # Verifica que el código de respuesta sea 422 (Unprocessable Entity)
    assert response.status_code == 422

    # Verifica que no se llamó a launch_agents con los parámetros incorrectos
    mock_launch.assert_not_called()


@patch("src.api.agent_manager.launch_agents")
def test_launch_agents_complex_resources(mock_launch, mock_agent_response):
    """
    Test para verificar que el endpoint acepta recursos complejos válidos.

    Verifica que el endpoint /api/launch_agents procese correctamente
    cuando se envían recursos complejos (anidados) que son válidos.
    """
    # Configura el mock para devolver una lista con un agente
    mock_launch.return_value = [mock_agent_response]

    # Datos para la solicitud con recursos complejos
    payload = {
        "agents": ["test-agent"],
        "resources": {
            "database": {
                "host": "localhost",
                "port": 5432,
                "credentials": {"username": "test_user", "password": "test_password"},
            },
            "api_keys": ["key1", "key2", "key3"],
            "timeout": 30,
            "retries": 3,
        },
    }

    # Realiza la solicitud POST al endpoint
    response = client.post("/api/launch_agents", json=payload)

    # Verifica que el código de respuesta sea 200 (OK)
    assert response.status_code == 200

    # Verifica que se llamó al método launch_agents con los parámetros correctos
    mock_launch.assert_called_once_with(payload["agents"], payload["resources"])


@patch("src.api.agent_manager.launch_agents")
def test_launch_agents_empty_agents_list(mock_launch):
    """
    Test para verificar el comportamiento con lista vacía de agentes.

    La API actualmente permite listas vacías de agentes. Este test verifica
    que se llame a launch_agents con una lista vacía y documenta este comportamiento.
    """
    
    # Configurar el mock para devolver una lista vacía (simulando éxito)
    mock_launch.return_value = []

    # Payload con lista vacía de agentes
    payload = {"agents": [], "resources": {"test-key": "test-value"}}

    # Realiza la solicitud POST al endpoint
    response = client.post("/api/launch_agents", json=payload)

    # La API acepta listas vacías con código 200
    assert response.status_code == 200

    # Verificar que se llamó a launch_agents con la lista vacía
    mock_launch.assert_called_once_with([], {"test-key": "test-value"})

    # Añadir comentario sobre este comportamiento para informar a futuros desarrolladores
    print(
        "NOTA: La API actualmente acepta listas vacías de agentes. ESTO NO ESTÁ BIEN."
    )
