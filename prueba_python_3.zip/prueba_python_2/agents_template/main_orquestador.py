"""
Servicio del agente orquestador.

Este agente especial centraliza información sobre todos los agentes en ejecución
y proporciona endpoints para consultar sus manifiestos y realizar otras operaciones.
"""

import uvicorn
from fastapi import FastAPI, BackgroundTasks
import os
import time
import json
from pathlib import Path
from pydantic import BaseModel
from loguru import logger

# Puerto y nombre del agente
AGENT_PORT = {{AGENT_PORT}}
AGENT_NAME = "orquestador"

# Crea la aplicación y registra el tiempo de inicio del servicio
app = FastAPI(title=f"{AGENT_NAME} Agent Service")
start_time = time.time()


class PromptRequest(BaseModel):
    """Modelo para solicitudes de del endpoint promptInput"""

    prompt: str


def scan_agent_manifests():
    """
    Escanea todos los directorios de agentes buscando archivos de manifiesto,
    los almacena en un objeto y los devuelve en la petición.

    La estructura devuelta usa el ID del agente como clave principal.

    Returns:
        Dict: Diccionario con información de manifiestos por ID de agente
    """

    # Objeto de manifiestos y path del directorio de agentes
    manifests = {}
    agents_dir = Path("agents")

    logger.debug("Escaneando manifiestos de agentes")
    # Busca en cada carpeta de agente excluyendo el orquestador
    for agent_dir in agents_dir.iterdir():
        if agent_dir.is_dir() and agent_dir.name != "orquestador":
            # Directorio del agente
            agent_name = agent_dir.name

            # Busca archivos de manifiesto del agente
            for manifest_file in agent_dir.glob("manifest_resources_*.json"):
                try:
                    port = int(manifest_file.stem.split("_")[-1])
                    with open(manifest_file, "r") as f:
                        manifest_data = json.load(f)

                    # Extraer el ID del agente si está disponible, de lo contrario usar un identificador generado
                    agent_id = manifest_data.pop("agent_id", f"{agent_name}_{port}")

                    # Incluir el nombre del agente en los recursos para mantener la referencia
                    if "agent_name" not in manifest_data:
                        manifest_data["agent_name"] = agent_name

                    # Añadir el puerto
                    manifests[agent_id] = {"port": port, "resources": manifest_data}
                    logger.debug(
                        f"Manifiesto encontrado para agente {agent_name} en puerto {port}"
                    )
                except Exception as e:
                    logger.error(f"Error al leer manifiesto {manifest_file}: {str(e)}")

    logger.info(f"Escaneados {len(manifests)} manifiestos de agentes")
    return manifests


def get_resources():
    """Obtiene los recursos asignados al agente desde el archivo JSON"""

    try:
        resources_file = Path(
            f"agents/{AGENT_NAME}/manifest_resources_{AGENT_PORT}.json"
        )

        if resources_file.exists():
            with open(resources_file, "r") as f:
                resources = json.load(f)
                logger.debug(f"Recursos cargados: {resources}")
                return resources
        logger.debug("No se encontraron recursos asignados al orquestador")
        return {}
    except Exception as e:
        logger.error(f"Error al cargar recursos: {e}")
        return {}


def shutdown_server():
    """
    Realiza un graceful shutdown del servidor
    Espera 1 segundo antes de cerrar para permitir que la respuesta
    HTTP sea enviada al cliente y termina el proceso
    """

    logger.info(f"Cerrando servicio del orquestador en puerto {AGENT_PORT}")
    time.sleep(1)
    os._exit(0)


@app.get("/")
def read_root():
    """Endpoint raíz que identifica el servicio."""
    logger.debug("Solicitud recibida en endpoint raíz del orquestador")
    return {
        "message": f"Hola, soy el agente {AGENT_NAME} y estoy corriendo en el puerto {AGENT_PORT}"
    }


@app.get("/status")
def status():
    """Proporciona información sobre el estado del servicio."""
    uptime = time.time() - start_time
    logger.debug(f"Solicitud de estado recibida. Uptime: {uptime:.2f} segundos")
    return {
        "status": "running",
        "agent": AGENT_NAME,
        "port": AGENT_PORT,
        "pid": os.getpid(),
        "uptime_seconds": uptime,
    }


@app.get("/resources")
def resources():
    """
    Busca el fichero con los resources para este microservicio
    Si lo encuentra lo devuelve en la respuesta de la petición
    """
    logger.debug("Solicitud de recursos recibida")
    return get_resources()


@app.get("/manifests")
def get_manifests():
    """Devuelve información sobre todos los manifiestos de los agentes desplegados."""
    logger.info("Solicitud de manifiestos recibida")
    return scan_agent_manifests()


@app.post("/prompt")
def promptInput(request: PromptRequest):
    """Endpoint que simplemente devuelve el input recibido."""
    logger.debug(
        f"Prompt recibido: {request.prompt[:50]}..."
        if len(request.prompt) > 50
        else request.prompt
    )
    return {"prompt": request.prompt}


@app.get("/shutdown")
def shutdown(background_tasks: BackgroundTasks):
    """Inicia el proceso de apagado controlado del servicio."""
    logger.info("Solicitud de cierre recibida para el orquestador")
    background_tasks.add_task(shutdown_server)

    return {"message": "Servicio cerrándose..."}


if __name__ == "__main__":
    logger.info(f"Iniciando agente orquestador en puerto {AGENT_PORT}")
    uvicorn.run(app, host="0.0.0.0", port=AGENT_PORT)
