import os
import random
import yaml

from fastapi import FastAPI, Body, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel


class PromptRequest(BaseModel):
    prompt: str


app = FastAPI()

# Configurar CORS para permitir peticiones desde el frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/agent_1")
async def agent_1(request: PromptRequest):
    prompt = request.prompt
    # Respuesta del agente 1 con formato HTML
    html_response = f"""
    <div class="agent-response">
        <h3 style="color: #e53e3e;">Agente 1</h3>
        <p>Has preguntado: <strong>{prompt}</strong></p>
        <p>Esta es la respuesta del Agente 1. Especializado en procesamiento de lenguaje natural.</p>
    </div>
    """
    return {"html": html_response}


@app.post("/agent_2")
async def agent_2(request: PromptRequest):
    prompt = request.prompt
    # Respuesta del agente 2 con formato HTML
    html_response = f"""
    <div class="agent-response">
        <h3 style="color: #38a169;">Agente 2</h3>
        <p>Tu consulta: <strong>{prompt}</strong></p>
        <p>Respuesta del Agente 2. Especializado en análisis de datos y visualización.</p>
        <ul>
            <li>Punto de análisis 1</li>
            <li>Punto de análisis 2</li>
        </ul>
    </div>
    """
    return {"html": html_response}


@app.post("/agent_3")
async def agent_3(request: PromptRequest):
    prompt = request.prompt
    # Respuesta del agente 3 con formato HTML
    html_response = f"""
    <div class="agent-response">
        <h3 style="color: #3182ce;">Agente 3</h3>
        <p>Consulta recibida: <strong>{prompt}</strong></p>
        <p>Respuesta generada por el Agente 3. Especializado en generación de código y soluciones técnicas.</p>
        <pre style="background-color: #f0f0f0; padding: 10px; border-radius: 5px;">
// Ejemplo de código generado
function processData(input) {{
    return input.toUpperCase();
}}
        </pre>
    </div>
    """
    return {"html": html_response}


@app.post("/agent_4")
async def agent_4(request: PromptRequest):
    prompt = request.prompt
    # Respuesta del agente 4 con formato HTML
    html_response = f"""
    <div class="agent-response">
        <h3 style="color: #805ad5;">Agente 4</h3>
        <p>Has solicitado: <strong>{prompt}</strong></p>
        <p>El Agente 4 está procesando tu consulta. Especializado en resúmenes y síntesis de información.</p>
        <div style="border-left: 3px solid #805ad5; padding-left: 10px; margin: 10px 0;">
            Resumen generado basado en tu consulta. Este agente proporciona respuestas concisas y directas.
        </div>
    </div>
    """
    return {"html": html_response}


@app.post("/agent_5")
async def agent_5(request: PromptRequest):
    prompt = request.prompt
    # Respuesta del agente 5 con formato HTML
    html_response = f"""
    <div class="agent-response">
        <h3 style="color: #dd6b20;">Agente 5</h3>
        <p>Mensaje recibido: <strong>{prompt}</strong></p>
        <p>Respuesta del Agente 5. Especializado en recomendaciones personalizadas.</p>
        <table style="width:100%; border-collapse: collapse; margin-top: 10px;">
            <tr style="background-color: #f8f9fa;">
                <th style="padding: 8px; border: 1px solid #ddd;">Recomendación</th>
                <th style="padding: 8px; border: 1px solid #ddd;">Relevancia</th>
            </tr>
            <tr>
                <td style="padding: 8px; border: 1px solid #ddd;">Opción 1</td>
                <td style="padding: 8px; border: 1px solid #ddd;">Alta</td>
            </tr>
            <tr>
                <td style="padding: 8px; border: 1px solid #ddd;">Opción 2</td>
                <td style="padding: 8px; border: 1px solid #ddd;">Media</td>
            </tr>
        </table>
    </div>
    """
    return {"html": html_response}
