import React from "react";

const Footer = ({ footerText }) => {
  return (
    <footer className="py-2 text-center text-xs text-gray-600 dark:text-gray-400 bg-white dark:bg-gray-900">
      <p>{footerText}</p>
    </footer>
  );
};

export default Footer;
