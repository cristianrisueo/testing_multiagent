import { useState, useRef, useEffect, useCallback } from "react";
import { Send, RefreshCw } from "react-feather";
import axios from "axios";

const Chat = ({ inputPlaceholder, selectedEndpoint }) => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    // Mensaje del usuario
    const userMessage = {
      id: Date.now(),
      text: input,
      isUser: true,
      isHtml: false,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      // POST al backend
      const response = await axios.post(selectedEndpoint, {
        prompt: input,
      });
      // { html: "<h3>...</h3> ..." }
      const { html } = response.data;
      console.log("Respuesta del backend:", html);

      // Mensaje del "bot"
      const botMessage = {
        id: Date.now() + 1,
        text: html, // guardamos el string HTML
        isUser: false,
        isHtml: true, // indicamos que vamos a usar dangerouslySetInnerHTML
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      console.error("Error al procesar la consulta:", error);
      // Puedes añadir un mensaje de error en el chat si lo deseas
    }

    setIsLoading(false);
  };

  const handleReset = () => {
    setMessages([]);
    setInput("");
    setIsLoading(false);
  };

  return (
    <div className="flex-1 flex flex-col max-h-[calc(100vh-8rem)]">
      {/* Zona de mensajes */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50 dark:bg-gray-900">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${
              message.isUser ? "justify-end" : "justify-start"
            }`}
          >
            {/* Distinguimos entre HTML y texto plano */}
            {message.isHtml ? (
              <div
                className={`max-w-[80%] p-4 rounded-2xl bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-bl-none shadow-sm`}
                dangerouslySetInnerHTML={{ __html: message.text }}
              />
            ) : (
              <div
                className={`max-w-[80%] p-4 rounded-2xl ${
                  message.isUser
                    ? "bg-red-500 text-white rounded-br-none"
                    : "bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-bl-none shadow-sm"
                }`}
              >
                {message.text}
              </div>
            )}
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 p-4 rounded-2xl rounded-bl-none shadow-sm">
              Typing...
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Zona de input */}
      <div className="p-6 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900">
        <form onSubmit={handleSubmit} className="flex space-x-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={inputPlaceholder}
            className="flex-1 p-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500 dark:focus:ring-red-400"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading}
            className="px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="px-4 py-3 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
};

export default Chat;
