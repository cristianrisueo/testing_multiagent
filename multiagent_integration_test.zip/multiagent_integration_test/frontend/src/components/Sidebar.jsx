import { Box } from "react-feather";
import Logo from "../assets/santander_logo.png";

const Sidebar = ({
  isOpen,
  setIsOpen,
  setSelectedEndpoint,
  agentInfo,
  setSelectedAgentIndex,
}) => {
  const handleAgentSelect = (agentNumber) => {
    setSelectedEndpoint(`http://localhost:8000/agent_${agentNumber}`);
    setSelectedAgentIndex(agentNumber);
  };

  // Componente que encapsula el contenido común del sidebar
  const SidebarContent = () => (
    <nav className="flex-1 px-4 space-y-2">
      {/* Botón de "Solución 1" */}
      <button
        onClick={() => handleAgentSelect(1)}
        className="w-full flex items-center px-4 py-3 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
      >
        <Box className="w-5 h-5 mr-3" />
        <span className="font-medium">{agentInfo[0].title}</span>
      </button>

      {/* Botón de "Solución 2" */}
      <button
        onClick={() => handleAgentSelect(2)}
        className="w-full flex items-center px-4 py-3 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
      >
        <Box className="w-5 h-5 mr-3" />
        <span className="font-medium">{agentInfo[1].title}</span>
      </button>

      {/* Botón de "Solución 3" */}
      <button
        onClick={() => handleAgentSelect(3)}
        className="w-full flex items-center px-4 py-3 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
      >
        <Box className="w-5 h-5 mr-3" />
        <span className="font-medium">{agentInfo[2].title}</span>
      </button>

      {/* Botón de "Solución 4" */}
      <button
        onClick={() => handleAgentSelect(4)}
        className="w-full flex items-center px-4 py-3 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
      >
        <Box className="w-5 h-5 mr-3" />
        <span className="font-medium">{agentInfo[3].title}</span>
      </button>

      {/* Botón de "Solución 5" */}
      <button
        onClick={() => handleAgentSelect(5)}
        className="w-full flex items-center px-4 py-3 rounded-lg text-gray-700 dark:text-gray-200 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
      >
        <Box className="w-5 h-5 mr-3" />
        <span className="font-medium">{agentInfo[4].title}</span>
      </button>
    </nav>
  );

  return (
    <>
      {/* Sidebar en escritorio */}
      <div className="hidden lg:flex lg:flex-col lg:w-64 lg:h-screen bg-gray-50 dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700">
        <div className="flex justify-center items-center py-4 mb-6">
          <img
            src={Logo || "/placeholder.svg"}
            alt="Santander Logo"
            className="h-18 w-auto object-contain"
          />
        </div>
        <SidebarContent />
      </div>

      {/* Sidebar en móvil (drawer) */}
      <div
        className={`lg:hidden fixed top-0 left-0 z-40 w-64 h-full bg-gray-50 dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 transform transition-transform duration-300 ease-in-out ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full p-4">
          <div className="flex justify-center items-center py-4 mb-6">
            <img
              src={Logo || "/placeholder.svg"}
              alt="Santander Logo"
              className="h-18 w-auto object-contain"
            />
          </div>
          <SidebarContent />
        </div>
      </div>

      {isOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black bg-opacity-25 z-30"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
};

export default Sidebar;
