import { useTheme } from "../context/ThemeContext";
import { Menu, Sun, Moon } from "react-feather";

const Header = ({
  setIsSidebarOpen,
  title,
  subtitle,
  toggleLanguage,
  language,
}) => {
  const { isDarkMode, toggleTheme } = useTheme();

  return (
    <header className="p-6 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 flex flex-col md:flex-row items-center justify-between">
      {/* Título y subtítulo (dinámicos) */}
      <div className="flex-1 text-center md:text-left">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-200">
          {title}
        </h1>
        <p className="mt-2 text-lg text-gray-600 dark:text-gray-400">
          {subtitle}
        </p>
      </div>

      {/* Contenedor de botones */}
      <div
        className="
          mt-4 md:mt-0 
          flex flex-row items-center space-x-2
          md:flex-col md:items-end md:space-y-2 md:space-x-0
        "
      >
        {/* Botón hamburguesa (solo en móvil) */}
        <button
          onClick={() => setIsSidebarOpen(true)}
          className="block lg:hidden p-2 rounded-lg bg-gray-100 dark:bg-gray-800 transition-colors"
          aria-label="Open sidebar"
        >
          <Menu className="w-5 h-5 text-gray-600 dark:text-gray-300" />
        </button>

        {/* Botón para cambiar de idioma */}
        <button
          onClick={toggleLanguage}
          className="p-2 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          aria-label="Toggle language"
        >
          {language === "es" ? "ES" : "EN"}
        </button>

        {/* Botón para cambiar tema */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
          aria-label="Toggle theme"
        >
          {isDarkMode ? (
            <Sun className="w-5 h-5 text-yellow-500" />
          ) : (
            <Moon className="w-5 h-5 text-gray-600" />
          )}
        </button>
      </div>
    </header>
  );
};

export default Header;
