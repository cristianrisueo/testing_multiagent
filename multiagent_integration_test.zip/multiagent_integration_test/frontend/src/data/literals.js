const literals = {
  solutions: {
    multiagent: {
      es: {
        title: "Poc Multi-Agéntica",
        subtitle: "Frontend para testing de solución 'multiagéntica'",
      },
      en: {
        title: "Multi-Agent Platform",
        subtitle: "Frontend for testing purposes of 'multi-agent solution'.",
      },
    },
  },

  common: {
    es: {
      multiagentButton: "Solución multiagente",
      inputPlaceholder: "Escribe tu mensaje...",
      footerText:
        "Desarrollado con React.js y TailwindCSS. Desarrollado con ❤️",
      agents: [
        {
          title: "AWS Kendra - Bedrock",
        },
        {
          title: "AWS Kendra - SageMaker",
        },
        {
          title: "AWS Kendra - OpenAI",
        },
        {
          title: "AI Search Azure - OpenAI",
        },
        {
          title: "AI Search Azure - Azure OpenAI",
        },
      ],
    },
    en: {
      multiagentButton: "Multi-Agent Solution",
      inputPlaceholder: "Type your message...",
      footerText: "Powered by React.js and TailwindCSS. Developed with ❤️",
      agents: [
        {
          title: "AWS Kendra - Bedrock",
        },
        {
          title: "AWS Kendra - SageMaker",
        },
        {
          title: "AWS Kendra - OpenAI",
        },
        {
          title: "AI Search Azure - OpenAI",
        },
        {
          title: "AI Search Azure - Azure OpenAI",
        },
      ],
    },
  },
};

export default literals;
