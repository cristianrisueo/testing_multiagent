import { useState } from "react";
import { ThemeProvider } from "./context/ThemeContext";
import literals from "./data/literals";

import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import Chat from "./components/Chat";
import Footer from "./components/Footer";

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [selectedSolution, setSelectedSolution] = useState("multiagent");
  const [language, setLanguage] = useState("es");
  const [selectedAgentIndex, setSelectedAgentIndex] = useState(null);
  const [selectedEndpoint, setSelectedEndpoint] = useState(
    "http://localhost:8000/agent_1"
  );

  // Alterna solo entre "es" y "en"
  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "es" ? "en" : "es"));
  };

  // Obtener título y subtítulo
  const { title, subtitle } = literals.solutions[selectedSolution][language];
  const headerTitle =
    selectedAgentIndex !== null &&
    literals.common[language].agents[selectedAgentIndex - 1]
      ? literals.common[language].agents[selectedAgentIndex - 1].title
      : title;
  const headerSubtitle =
    selectedAgentIndex !== null &&
    literals.common[language].agents[selectedAgentIndex - 1]
      ? literals.common[language].agents[selectedAgentIndex - 1].description
      : subtitle;

  const { multiagentButton, inputPlaceholder, footerText } =
    literals.common[language];

  return (
    <ThemeProvider>
      <div className="flex h-screen bg-white dark:bg-gray-900 transition-colors duration-200 overflow-hidden">
        <Sidebar
          isOpen={isSidebarOpen}
          setIsOpen={setIsSidebarOpen}
          setSelectedSolution={(sol) => {
            setSelectedSolution(sol);
            setSelectedAgentIndex(null);
          }}
          multiagentButton={multiagentButton}
          language={language}
          agentInfo={literals.common[language].agents}
          setSelectedAgentIndex={setSelectedAgentIndex}
          setSelectedEndpoint={setSelectedEndpoint}
        />

        <main className="flex-1 flex flex-col">
          <Header
            isSidebarOpen={isSidebarOpen}
            setIsSidebarOpen={setIsSidebarOpen}
            title={headerTitle}
            subtitle={headerSubtitle}
            toggleLanguage={toggleLanguage}
            language={language}
          />
          <Chat
            inputPlaceholder={inputPlaceholder}
            selectedEndpoint={selectedEndpoint}
          />
          <Footer footerText={footerText} />
        </main>
      </div>
    </ThemeProvider>
  );
}

export default App;
