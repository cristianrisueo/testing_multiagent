# Proyecto React: Plataforma Multi-Agente

Este proyecto es una **aplicación React** (inicializada con [Create React App](https://github.com/facebook/create-react-app)) que implementa una interfaz de chat, un sistema de cambio de tema (claro/oscuro) y soporte multilenguaje (castellano/inglés). También incluye un **sidebar** responsive con navegación para seleccionar distintas “soluciones”.

## Tecnologías principales

- **React.js** (bootstrapped con Create React App)
- **TailwindCSS** para estilos
- **React Feather** para iconos
- **Context API** de React para gestionar tema y traducciones
- **JavaScript** / **JSX**

## Requisitos previos

- **Node.js** (versión 14 o superior)
- **npm** o **yarn** instalado en tu entorno

## Instalación

1. Clona este repositorio o descarga el código fuente.
2. Abre una terminal en la carpeta raíz del proyecto.
3. Instala las dependencias con:

   ```bash
   npm install
   ```

   o bien

   ```bash
   yarn install
   ```

## Scripts disponibles

En el directorio del proyecto, puedes ejecutar los siguientes comandos:

### `npm start`

Inicia la aplicación en modo de desarrollo.  
Abre [http://localhost:3000](http://localhost:3000) en tu navegador para ver la aplicación.  
La página se recargará al realizar cambios en el código.

### `npm run build`

Genera una versión lista para producción en la carpeta `build`.  
Se minifica y optimiza para obtener el mejor rendimiento.

### `npm test`

Ejecuta el test runner en modo interactivo.  
_(Deberás tener pruebas configuradas para sacarles partido.)_

### `npm run eject`

**¡Atención!** Este comando es irreversible. Extrae las configuraciones internas de Create React App para que tengas control total sobre Webpack, Babel, etc.

---

## Estructura del proyecto

- **`src/`**

  - **`App.jsx`**: Punto de entrada principal que integra el sidebar, header, chat y footer.
  - **`components/`**: Contiene componentes como _Sidebar_, _Header_, _Footer_ y _Chat_.
  - **`context/`**: Incluye los contextos de React (por ejemplo, `ThemeContext`).
  - **`literals.js`**: Fichero que agrupa los textos en distintos idiomas (castellano, inglés, etc.).
  - **`index.css`**: Estilos globales y configuración de Tailwind.

- **`public/`**
  - Archivos estáticos y `index.html`.

---

## Funcionalidades destacadas

### Cambio de tema (claro/oscuro)

- Incluye un botón para alternar ambos modos.
- Persiste la preferencia del usuario en `localStorage`.

### Soporte multilenguaje (castellano/inglés)

- Botón para cambiar de idioma.
- Textos gestionados desde un fichero de literales para una fácil ampliación.

### Sidebar responsive

- En _desktop_ se muestra fijo a la izquierda.
- En _móvil_ se despliega como un _drawer_ al pulsar un icono hamburguesa.

### Chat básico

- Permite enviar mensajes y recibir respuestas simuladas.
- Uso de hooks como `useState` y `useEffect`.

---

## Contribución

1. Haz un _fork_ de este repositorio.
2. Crea una rama para tu funcionalidad:
   ```bash
   git checkout -b feature/mi-funcionalidad
   ```
3. Realiza los cambios y haz commit:
   ```bash
   git commit -m "Descripción de cambios"
   ```
4. Sube los cambios a tu fork:
   ```bash
   git push origin feature/mi-funcionalidad
   ```

Este proyecto se distribuye bajo licencia MIT
