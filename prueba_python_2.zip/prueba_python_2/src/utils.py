import sys
import json
from pathlib import Path
from typing import List, Dict, Any
from .config import settings, app_logger as logger


def ensure_directories() -> None:
    """
    Asegura que existen las carpetas y archivos necesarios para la aplicación.

    Crea:
    - El directorio de datos
    - El archivo de agentes con valores por defecto
    - El directorio temporal para los servicios de agentes
    - Los directorios para cada agente definido en data/agents
    """

    # Crea los directorios necesarios, si no existen
    logger.info("Verificando directorios de la aplicación")
    settings.DATA_DIR.mkdir(exist_ok=True, parents=True)
    settings.TEMP_DIR.mkdir(exist_ok=True, parents=True)
    settings.AGENTS_DIR.mkdir(exist_ok=True, parents=True)

    # Crea archivo de agentes permitidos con valores los por defecto, si no existe
    if not settings.AGENTS_FILE.exists():
        logger.info("Creando archivo de agentes permitidos con valores por defecto")
        with open(settings.AGENTS_FILE, "w") as f:
            f.write("vfs\nkendra\nllama\ngpt4\norquestador\n")

    # Lista con los diferentes agentes disponibles
    available_agents = read_available_agents()
    logger.debug(f"Agentes disponibles: {available_agents}")

    # Para cada agente disponible excepto el orquestador, crea su carpeta y se
    # asegura que exista el main.py
    for agent_name in available_agents:
        if agent_name != "orquestador":
            agent_dir = settings.AGENTS_DIR / agent_name
            agent_dir.mkdir(exist_ok=True)
            agent_main_file = agent_dir / "main.py"

            # Si no existe el archivo main.py, lo crea a partir de la plantilla
            if not agent_main_file.exists():
                logger.info(f"Creando archivo main.py para el agente {agent_name}")
                create_agent_main_file(agent_name, agent_main_file)

    # Asegura que existe el directorio y archivo main.py para el orquestador
    orchestrator_dir = settings.AGENTS_DIR / "orquestador"
    orchestrator_dir.mkdir(exist_ok=True)
    orchestrator_main_file = orchestrator_dir / "main.py"

    # Siempre crea o sobrescribe el main.py del orquestador para asegurar que
    # se use la plantilla correcta
    logger.info("Actualizando archivo main.py del orquestador")
    create_orchestrator_main_file(orchestrator_main_file)


def read_available_agents() -> List[str]:
    """
    Lee los agentes disponibles del archivo de configuración de agentes.

    Returns:
        List[str]: Lista de nombres de agentes disponibles

    Note:
        Si el archivo no existe, se creará automáticamente con valores predeterminados.
    """

    # Lee los agentes disponibles de "data/agents", si no existe lo crea y lo intenta
    try:
        with open(settings.AGENTS_FILE, "r") as f:
            agents = [line.strip() for line in f if line.strip()]
            logger.debug(f"Leídos {len(agents)} agentes disponibles")
            return agents
    except FileNotFoundError:
        logger.warning(
            "Archivo de agentes no encontrado, creando con valores predeterminados"
        )

        ensure_directories()
        return read_available_agents()


def create_agent_main_file(agent_name: str, file_path: Path) -> None:
    """
    Crea el archivo main.py para un agente específico usando la plantilla.

    Args:
        agent_name (str): Nombre del agente
        file_path (Path): Ruta donde crear el archivo main.py
    """

    # Ruta a la plantilla de agentes
    template_path = Path(__file__).parent.parent / "agents_template" / "main_agente.py"

    try:
        # Lee la plantilla
        with open(template_path, "r") as f:
            template_content = f.read()

        # Reemplaza el nombre del agente
        content = template_content.replace("{{AGENT_NAME}}", agent_name)

        # Escribir al archivo del agente
        with open(file_path, "w") as f:
            f.write(content)

        logger.info(f"Archivo main.py creado para el agente {agent_name}")
    except Exception as e:
        logger.error(
            f"Error al crear el archivo main.py para el agente {agent_name}: {str(e)}"
        )
        raise


def create_orchestrator_main_file(file_path: Path) -> None:
    """
    Crea el archivo main.py para el agente orquestador usando la plantilla.

    Args:
        file_path (Path): Ruta donde crear el archivo main.py
    """

    # Ruta a la plantilla del orquestador
    template_path = (
        Path(__file__).parent.parent / "agents_template" / "main_orquestador.py"
    )

    try:
        # Lee la plantilla
        with open(template_path, "r") as f:
            template_content = f.read()

        # Escribir al archivo del agente orquestador
        with open(file_path, "w") as f:
            f.write(template_content)

        logger.info("Archivo main.py del orquestador creado/actualizado")
    except Exception as e:
        logger.error(
            f"Error al crear el archivo main.py para el agente orquestador: {str(e)}"
        )
        raise


def save_agent_resources(
    agent_name: str, port: int, resources: Dict[str, Any], agent_id: str = None
) -> str:
    """
    Guarda los recursos del agente en un archivo JSON.

    Args:
        agent_name (str): Nombre del agente
        port (int): Puerto del servicio
        resources (Dict): Recursos a guardar
        agent_id (str, optional): ID del agente para incluir en los recursos

    Returns:
        str: Ruta al archivo de recursos creado
    """

    # Ruta de la carpeta y ruta del fichero
    agent_dir = settings.AGENTS_DIR / agent_name
    resources_file = agent_dir / f"manifest_resources_{port}.json"

    # Incluir el ID del agente en los recursos para que el orquestador pueda identificarlo
    resources_to_save = resources.copy() if resources else {}

    # Si se proporciona un ID de agente, incluirlo en los recursos
    if agent_id:
        resources_to_save["agent_id"] = agent_id

    # También guardar el nombre del agente para referencia
    resources_to_save["agent_name"] = agent_name

    # Intenta guardar el fichero en la ruta y lo devuelve el la respuesta
    try:
        with open(resources_file, "w") as f:
            json.dump(resources_to_save, f, indent=2)

        logger.debug(
            f"Recursos guardados para {agent_name} en puerto {port}: {resources_file}"
        )
        return str(resources_file)
    except Exception as e:
        logger.error(f"Error al guardar recursos del agente {agent_name}: {str(e)}")
        raise IOError(f"Error al guardar recursos del agente: {str(e)}")


def clean_agent_resources(agent_name: str, port: int) -> bool:
    """
    Elimina el fichero resources de la carpeta del respectivo agente cuando se elimina
    el microservicio asociado (puerto). Un agente puede estar instanciado varias veces

    Args:
        agent_name (str): Nombre del agente
        port (int): Puerto del servicio

    Returns:
        bool: True si se eliminó correctamente, False si no existía o hubo un error
    """

    try:
        resources_file = (
            settings.AGENTS_DIR / agent_name / f"manifest_resources_{port}.json"
        )

        if resources_file.exists():
            resources_file.unlink()
            logger.debug(f"Recursos eliminados para {agent_name} en puerto {port}")
            return True

        logger.debug(f"No se encontraron recursos para {agent_name} en puerto {port}")
        return False
    except Exception as e:
        logger.error(f"Error al eliminar recursos del agente {agent_name}: {e}")
        return False


def generate_agent_service_command(agent_name: str, port: int) -> List[str]:
    """
    Genera el comando para iniciar el servicio del agente.

    Args:
        agent_name (str): Nombre del agente
        port (int): Puerto para el servicio

    Returns:
        List[str]: Comando para iniciar el servicio
    """

    # Determinar la ruta del archivo main.py del agente
    agent_main_file = settings.AGENTS_DIR / agent_name / "main.py"

    # Verifica que exista el fichero main del agente
    if not agent_main_file.exists():
        logger.error(f"No se encontró el archivo main.py para el agente {agent_name}")
        raise IOError(f"No se encontró el archivo main.py para el agente {agent_name}")

    # Crea archivo temporal para el micro en la carpeta "temp"
    temp_service_file = settings.TEMP_DIR / f"agent_service_{port}.py"

    try:
        # Lee la plantilla del agente "agents/{AGENTE_X}/main.py"
        with open(agent_main_file, "r") as f:
            content = f.read()

        # Reemplaza el puerto en la plantilla del agente
        content = content.replace("{{AGENT_PORT}}", str(port))

        # Escribi el archivo temporal
        with open(temp_service_file, "w") as f:
            f.write(content)

        logger.debug(
            f"Generado archivo temporal de servicio para {agent_name} en {temp_service_file}"
        )
        # Devolve el comando para ejecutar el microservicio
        return [sys.executable, str(temp_service_file)]
    except Exception as e:
        logger.error(f"Error al generar el archivo del servicio para {agent_name}: {e}")
        raise IOError(f"Error al generar el archivo del servicio: {str(e)}")


def clean_agent_service_file(port: int) -> bool:
    """
    Elimina el archivo temporal del servicio del agente.

    Args:
        port (int): Puerto del servicio cuyo archivo debe eliminarse

    Returns:
        bool: True si se eliminó correctamente, False si no existía o hubo un error
    """

    # Busca el fichero en el directorio temporal. Si lo encuentra lo elimina
    # y devuelve True. Si no devuelve False
    try:
        service_file = settings.TEMP_DIR / f"agent_service_{port}.py"

        if service_file.exists():
            service_file.unlink()
            logger.debug(f"Archivo de servicio eliminado para puerto {port}")
            return True

        logger.debug(f"No se encontró archivo de servicio para puerto {port}")
        return False
    except Exception as e:
        logger.error(f"Error al eliminar archivo de servicio para puerto {port}: {e}")
        return False  # Ante error de limpieza también devuelve false
