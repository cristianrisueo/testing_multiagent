from fastapi import FastAPI
import uvicorn
from contextlib import asynccontextmanager
from .api import router as api_router
from .config import settings, app_logger as logger
from .utils import ensure_directories
from .services import agent_manager


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Manejador del ciclo de vida de la aplicación.

    Se ejecuta al iniciar y detener la aplicación:
    - Al iniciar: Asegura que existan las carpetas y archivos necesarios
                  Inicia el agente orquestador si es necesario
    - Al detener: Detiene todos los agentes en ejecución
    """

    # Código que se ejecuta al iniciar la aplicación
    ensure_directories()
    logger.info(
        f"{settings.APP_NAME} v{settings.VERSION} iniciado en el puerto {settings.PORT}"
    )

    # Cede el control a la aplicación
    yield

    # Código que se ejecuta al cerrar la aplicación
    logger.info("Deteniendo todos los agentes activos...")

    await agent_manager.stop_all_agents()
    logger.info("Aplicación cerrada correctamente")


# Crea la aplicación y registra las rutas
app = FastAPI(
    title=settings.APP_NAME,
    description="API para gestionar agentes de IA generativa como microservicios",
    version=settings.VERSION,
    lifespan=lifespan,
)

app.include_router(api_router, prefix="/api")


@app.get("/")
def read_root():
    """
    Endpoint raíz que actúa como health check y devuelve información sobre la API
    """

    return {
        "app": settings.APP_NAME,
        "description": "API para gestionar agentes de IA generativa como microservicios",
        "endpoints": {
            "launch_agents": "/api/launch_agents",
            "stop_agent": "/api/stop_agent",
            "list_agents": "/api/list_agents",
        },
    }
