import sys
import json
from typing import List, Dict, Any
from .config import settings, app_logger as logger


def ensure_directories() -> None:
    """
    Asegura que existen las carpetas básicas necesarias para la aplicación.

    Crea:
    - El directorio temporal para las instancias de agentes
    - El directorio de logs
    """

    logger.info("Verificando directorios básicos de la aplicación")
    settings.TEMP_DIR.mkdir(exist_ok=True, parents=True)
    settings.LOG_DIR.mkdir(exist_ok=True, parents=True)


def save_agent_resources(
    agent_name: str, port: int, resources: Dict[str, Any], agent_id: str = None
) -> str:
    """
    Guarda los recursos del agente en un archivo JSON.

    Args:
        agent_name (str): Nombre del agente
        port (int): Puerto del servicio
        resources (Dict): Recursos a guardar
        agent_id (str, optional): ID del agente para incluir en los recursos

    Returns:
        str: Ruta al archivo de recursos creado
    """

    # Ruta de la carpeta y ruta del fichero
    agent_dir = settings.AGENTS_DIR / agent_name
    resources_file = agent_dir / f"manifest_resources_{port}.json"

    # Guarda los resources recibidos si hay, si no es un dic vacío
    resources_to_save = resources.copy() if resources else {}

    # Si se proporciona un ID de agente, lo guarda en los recursos
    if agent_id:
        resources_to_save["agent_id"] = agent_id

    # También guardar el nombre del agente si se proporciona
    resources_to_save["agent_name"] = agent_name

    # Intenta guardar el fichero en la ruta y lo devuelve el la respuesta
    try:
        with open(resources_file, "w") as f:
            json.dump(resources_to_save, f, indent=2)

        logger.debug(
            f"Recursos guardados para {agent_name} en puerto {port}: {resources_file}"
        )
        return str(resources_file)
    except Exception as e:
        logger.error(f"Error al guardar recursos del agente {agent_name}: {str(e)}")
        raise IOError(f"Error al guardar recursos del agente: {str(e)}")


def clean_agent_resources(agent_name: str, port: int) -> bool:
    """
    Elimina el fichero resources de la carpeta del respectivo agente cuando se elimina
    el microservicio asociado (puerto). Un agente puede estar instanciado varias veces

    Args:
        agent_name (str): Nombre del agente
        port (int): Puerto del servicio

    Returns:
        bool: True si se eliminó correctamente, False si no existía o hubo un error
    """

    try:
        resources_file = (
            settings.AGENTS_DIR / agent_name / f"manifest_resources_{port}.json"
        )

        if resources_file.exists():
            resources_file.unlink()
            logger.debug(f"Recursos eliminados para {agent_name} en puerto {port}")
            return True

        logger.debug(f"No se encontraron recursos para {agent_name} en puerto {port}")
        return False
    except Exception as e:
        logger.error(f"Error al eliminar recursos del agente {agent_name}: {e}")
        return False


def generate_agent_service_command(agent_name: str, port: int) -> List[str]:
    """
    Genera el comando para iniciar el servicio del agente.
    Verifica que exista el archivo asgi.py del agente.

    Args:
        agent_name (str): Nombre del agente
        port (int): Puerto para el servicio

    Returns:
        List[str]: Comando para iniciar el servicio

    Raises:
        IOError: Si no se encuentra el archivo asgi.py del agente
    """

    # Ruta del archivo asgi.py del agente
    agent_asgi_file = settings.AGENTS_DIR / agent_name / "asgi.py"

    # Comprueba que exista el fichero asgi del agente
    if not agent_asgi_file.exists():
        logger.error(f"No se encontró el archivo asgi.py para el agente {agent_name}")
        raise IOError(f"No se encontró el archivo asgi.py para el agente {agent_name}")

    # Crea archivo temporal para el micro en la carpeta "temp"
    temp_service_file = settings.TEMP_DIR / f"agent_service_{port}.py"

    try:
        # Lee la plantilla del agente "agents/{AGENTE_X}/asgi.py"
        with open(agent_asgi_file, "r") as f:
            content = f.read()

        # Reemplaza el puerto en el archivo del agente
        content = content.replace("{{AGENT_PORT}}", str(port))

        # Escribe el archivo temporal
        with open(temp_service_file, "w") as f:
            f.write(content)

        logger.debug(
            f"Generado archivo temporal de servicio para {agent_name} en {temp_service_file}"
        )
        
        # Devuelve el comando para ejecutar el microservicio
        return [sys.executable, str(temp_service_file)]
    except Exception as e:
        logger.error(f"Error al generar el archivo del servicio para {agent_name}: {e}")
        raise IOError(f"Error al generar el archivo del servicio: {str(e)}")


def clean_agent_service_file(port: int) -> bool:
    """
    Elimina el archivo temporal del servicio del agente.

    Args:
        port (int): Puerto del servicio cuyo archivo debe eliminarse

    Returns:
        bool: True si se eliminó correctamente, False si no existía o hubo un error
    """

    # Busca el fichero en el directorio temporal. Si lo encuentra lo elimina
    # y devuelve True. Si no devuelve False
    try:
        service_file = settings.TEMP_DIR / f"agent_service_{port}.py"

        if service_file.exists():
            service_file.unlink()
            logger.debug(f"Archivo de servicio eliminado para puerto {port}")
            return True

        logger.debug(f"No se encontró archivo de servicio para puerto {port}")
        return False
    except Exception as e:
        logger.error(f"Error al eliminar archivo de servicio para puerto {port}: {e}")
        return False  # Ante error de limpieza también devuelve false
