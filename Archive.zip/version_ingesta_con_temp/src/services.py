import subprocess
import time
import requests
import os
import signal
import psutil
import asyncio
from typing import Dict, List, Tuple, Optional, Union
from .config import settings, app_logger as logger
from .utils import (
    generate_agent_service_command,
    clean_agent_service_file,
    save_agent_resources,
    clean_agent_resources,
)
from .models import (
    AgentInfo,
    AgentStatus,
    AgentNotAvailableError,
    AgentStartupError,
    AgentNotFoundError,
    AgentShutdownError,
)


class AgentService:
    """
    Servicio responsable de la creación y eliminación de agentes individuales.

    Esta clase implementa las operaciones de bajo nivel necesarias para:
    - Iniciar un nuevo proceso para un agente en un puerto específico
    - Verificar que el servicio esté respondiendo correctamente
    - Realizar un apagado controlado de los procesos
    - Gestionar recursos temporales como archivos de servicio

    Actúa como una capa de abstracción entre el gestor de agentes (AgentManager) y
    los procesos del sistema operativo, encapsulando los detalles de implementación
    relacionados con la ejecución y comunicación con los procesos individuales.
    En el fondo son métodos estáticos, están actuándo como funciones puras.
    """

    @staticmethod
    async def start_agent(
        agent_name: str, port: int, resources: Dict = None, agent_id: str = None
    ) -> Tuple[int, str]:
        """
        Inicia un nuevo servicio para el agente en el puerto especificado con más logs de depuración

        Args:
            agent_name (str): Nombre del agente
            port (int): Puerto para el servicio
            resources (Dict, optional): Recursos a asignar al agente
            agent_id (str, optional): ID del agente para incluir en los recursos

        Returns:
            Tuple[int, str]: PID del proceso y ruta al archivo del servicio

        Raises:
            AgentStartupError: Si hay un error al iniciar el servicio
        """

        logger.info(f"Iniciando agente {agent_name} en puerto {port}")

        try:
            # Guarda los recursos como un archivo JSON
            if resources:
                resource_file = save_agent_resources(
                    agent_name, port, resources, agent_id
                )
                logger.debug(f"Recursos guardados en {resource_file}")

            # Crea el comando para iniciar el agente
            command = generate_agent_service_command(agent_name, port)
            logger.debug(f"Comando de inicio: {' '.join(command)}")

            # Inicia el proceso y guarda el PID
            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            pid = process.pid
            logger.info(f"Proceso iniciado con PID: {pid}")

            # Captura la salida temprana del proceso para diagnosticar problemas
            try:
                stdout, stderr = process.communicate(timeout=2)

                if stdout:
                    logger.debug(f"Salida estándar: {stdout.decode('utf-8')}")
                if stderr:
                    logger.warning(f"Error de inicio: {stderr.decode('utf-8')}")
            except subprocess.TimeoutExpired:
                logger.debug("Proceso iniciado correctamente")

            # Espera a que el servicio esté disponible
            service_ready = False
            start_time = time.time()

            # Intenta hacer una solicitud al endpoint de check del estado del servicio
            while (
                not service_ready
                and time.time() - start_time < settings.AGENT_STARTUP_TIMEOUT
            ):
                try:
                    logger.debug(
                        f"Intentando conectar a http://localhost:{port}/status"
                    )

                    response = requests.get(
                        f"http://localhost:{port}/status", timeout=1
                    )

                    logger.debug(f"Status de la respuesta: {response.status_code}")
                    logger.debug(f"Contenido de la respuesta: {response.text}")

                    if response.status_code == 200:
                        service_ready = True
                    else:
                        await asyncio.sleep(0.5)
                except (requests.RequestException, ConnectionError) as e:
                    logger.debug(f"Error de conexión: {e}")
                    await asyncio.sleep(0.5)

            # Si no puede llamar al endpoint del servicio elimina el proceso y lanza una excepción
            if not service_ready:
                try:
                    logger.warning(
                        f"El servicio {agent_name} no respondió a tiempo, terminando..."
                    )

                    process.terminate()
                    process.wait(timeout=3)

                    # Limpia los recursos (JSON) si falló
                    clean_agent_resources(agent_name, port)
                except Exception as e:
                    logger.error(
                        f"Error al terminar el proceso tras tiempo de espera: {e}"
                    )

                # Lanza excepción al no poder llamar al agente
                raise AgentStartupError(
                    agent_name=agent_name,
                    details=f"El servicio no respondió en {settings.AGENT_STARTUP_TIMEOUT} segundos",
                )

            # Si todo va bien devuelve el PID y el fichero temporal con la info del servicio
            temp_service_file = settings.TEMP_DIR / f"agent_service_{port}.py"
            logger.info(
                f"Agente {agent_name} iniciado exitosamente en puerto {port} con PID {pid}"
            )

            return pid, str(temp_service_file)
        except Exception as e:
            logger.error(f"Error crítico de inicio para agente {agent_name}: {e}")

            # Limpiar recursos en caso de error
            clean_agent_resources(agent_name, port)
            raise AgentStartupError(agent_name=agent_name, details=str(e))

    @staticmethod
    async def stop_agent(agent_name: str, port: int, pid: int) -> bool:
        """
        Detiene un servicio de agente. Intenta hacer un graceful shutdown y si falla mata el
        proceso directamente

        Args:
            agent_name (str): Nombre del agente
            port (int): Puerto del servicio
            pid (int): PID del proceso

        Returns:
            bool: True si se detuvo correctamente, False en caso contrario
        """

        logger.info(f"Deteniendo agente {agent_name} en puerto {port} con PID {pid}")

        try:
            # Llama al endpoint del agente para detener el servicio con un graceful shutdown
            # y guarda el tiempo de la ejecución
            logger.debug(
                f"Intentando shutdown graceful para http://localhost:{port}/shutdown"
            )

            requests.get(f"http://localhost:{port}/shutdown", timeout=2)
            start_time = time.time()

            # Comprueba si el proceso sigue vivo. Si no sigue vivo limpia los recursos (JSON)
            # si algo falla limpia los recursos igualmente
            while time.time() - start_time < settings.AGENT_SHUTDOWN_TIMEOUT:
                try:
                    if not psutil.pid_exists(pid):
                        clean_agent_resources(agent_name, port)
                        clean_agent_service_file(port)

                        logger.info(
                            f"Agente {agent_name} detenido correctamente (graceful shutdown)"
                        )

                        return True
                except Exception as e:
                    logger.debug(f"Error verificando PID {pid}: {e}")

                    clean_agent_resources(agent_name, port)
                    clean_agent_service_file(port)

                    logger.info(f"Agente {agent_name} detenido (presumiblemente)")

                    return True  # Si hay un error al comprobar si el proceso sigue vivo asume que no existe

                await asyncio.sleep(0.5)

            # Si el proceso sigue vivo después del timeout, lo mata (cierra el servicio del agente a la fuerza)
            logger.warning(
                f"Graceful shutdown falló para agente {agent_name}, forzando terminación..."
            )

            try:
                os.kill(pid, signal.SIGTERM)
                await asyncio.sleep(1)

                if psutil.pid_exists(pid):
                    logger.warning(
                        f"SIGTERM no terminó el proceso {pid}, enviando SIGKILL"
                    )
                    os.kill(pid, signal.SIGKILL)

                # Limpia los recursos tras matar el proceso forzosamente
                clean_agent_resources(agent_name, port)
                clean_agent_service_file(port)

                logger.info(f"Agente {agent_name} terminado forzosamente")

                return True
            except Exception as e:
                logger.error(f"Error al matar forzosamente el proceso {pid}: {e}")
                return False
        except requests.RequestException as e:
            # Si falla la solicitud HTTP, intenta matar el proceso directamente
            logger.warning(f"Error al solicitar shutdown al agente {agent_name}: {e}")
            logger.warning(f"Intentando matar el proceso directamente")

            try:
                os.kill(pid, signal.SIGTERM)
                await asyncio.sleep(1)

                if psutil.pid_exists(pid):
                    logger.warning(
                        f"SIGTERM no terminó el proceso {pid}, enviando SIGKILL"
                    )
                    os.kill(pid, signal.SIGKILL)

                # Lipia los recursos tras matar el proceso forzosamente
                clean_agent_resources(agent_name, port)
                clean_agent_service_file(port)

                logger.info(
                    f"Agente {agent_name} terminado forzosamente tras error HTTP"
                )

                return True
            except Exception as e:
                logger.error(f"Error al matar proceso {pid}: {e}")
                return False


class AgentManager:
    """
    Controlador central que coordina y administra el ciclo de vida completo de todos los agentes.

    Esta clase actúa como un orquestador y registro central, responsable de:
    - Mantener un inventario actualizado de todos los agentes en ejecución y sus estados
    - Asignar puertos disponibles para nuevos servicios de agentes
    - Validar la disponibilidad de agentes solicitados contra el catálogo de agentes permitidos
    - Lanzar múltiples agentes en paralelo y supervisar su estado
    - Proporcionar operaciones de filtrado y búsqueda para localizar agentes específicos
    - Coordinar el apagado ordenado de servicios activos durante el cierre del sistema
    - Manejar la recuperación ante fallos y garantizar la limpieza de recursos

    Funciona como la capa intermedia entre la API REST y los servicios de agentes individuales,
    aislando la lógica de negocio de los detalles de implementación del sistema operativo.
    """

    def __init__(self):
        """
        Constructor del gestor de agentes
        Mantiene una "memoria interna" con un registro de la información de los agentes,
        el último puerto asignado y los puertos disponibles
        """

        self.agent_registry: Dict[str, AgentInfo] = {}
        self.last_assigned_port = settings.MIN_AGENT_PORT - 1
        self.available_ports = []

        logger.debug("AgentManager inicializado")

    def get_next_available_port(self) -> int:
        """
        Obtiene el siguiente puerto disponible.
        Primero intenta usar puertos que ya han sido liberados.
        Si no hay puertos liberados disponibles, incrementa el contador y asigna uno nuevo.

        Returns:
            int: Número de puerto disponible
        """

        # Busca puertos disponibles en la lista de puertos liberados
        # (agentes iniciados y luego eliminados que dejan su puerto libre)
        if self.available_ports:
            port = self.available_ports.pop(0)
            logger.debug(f"Reutilizando puerto previamente liberado: {port}")
            return port

        # Si no hay puertos liberados disponibles, obiene el siguiente el siguiente
        self.last_assigned_port += 1

        # Verifica si el puerto ya está en uso o fuera del rango permitido
        while (
            self.last_assigned_port
            in [agent.port for agent in self.agent_registry.values()]
            or self.last_assigned_port > settings.MAX_AGENT_PORT
        ):
            self.last_assigned_port += 1
            if self.last_assigned_port > settings.MAX_AGENT_PORT:

                logger.warning("Restableciendo contador de puertos al llegar al máximo")
                self.last_assigned_port = settings.MIN_AGENT_PORT

        # Devuelve el puerto incrementado o sobrescrito
        logger.debug(f"Asignando nuevo puerto: {self.last_assigned_port}")
        return self.last_assigned_port

    async def launch_agents(
        self, agent_names: List[str], resources: Dict = None
    ) -> List[AgentInfo]:
        """
        Lanza múltiples agentes. Intenta iniciar cada agente directamente.
        Si un agente no está disponible (su directorio o archivo asgi.py no existe),
        se lanza una excepción.

        Args:
            agent_names (List[str]): Lista de nombres de agentes a lanzar
            resources (Dict, optional): Recursos a asignar a los agentes

        Returns:
            List[AgentInfo]: Información de los agentes lanzados

        Raises:
            AgentNotAvailableError: Si algún agente solicitado no está disponible
        """
        logger.info(f"Solicitando lanzamiento de agentes: {agent_names}")

        # Verificamos que los directorios base existan
        agent_dir = settings.AGENTS_DIR
        if not agent_dir.exists():
            logger.warning(f"El directorio de agentes no existe: {agent_dir}")
            raise IOError(f"El directorio de agentes no existe: {agent_dir}")

        # Lanzamos los agentes directamente
        launched_agents = []
        for agent_name in agent_names:
            # Verificamos la existencia del directorio del agente
            specific_agent_dir = settings.AGENTS_DIR / agent_name
            if not specific_agent_dir.exists():
                logger.warning(
                    f"Agente solicitado no disponible: {agent_name} - Directorio no encontrado"
                )
                raise AgentNotAvailableError(agent_name)

            # Recoge los recursos para este agente (si existen)
            agent_resources = resources.get(agent_name, {}) if resources else {}

            # Añade los recursos globales
            if resources:
                # Filtra recursos que no son específicos de agentes
                global_resources = {
                    k: v for k, v in resources.items() if k not in agent_names
                }

                # Combina con recursos específicos del agente (los específicos tienen prioridad)
                agent_resources = {**global_resources, **agent_resources}

            logger.debug(
                f"Lanzando agente {agent_name} con recursos: {agent_resources}"
            )

            try:
                agent_info = await self.launch_agent(agent_name, agent_resources)
                launched_agents.append(agent_info)
            except IOError as e:
                # Captura errores de archivo no encontrado y los convierte en AgentNotAvailableError
                logger.error(f"Error al lanzar agente {agent_name}: {e}")
                raise AgentNotAvailableError(agent_name)

        # Devuelve la lista con la información de los agentes
        logger.info(
            f"Agentes lanzados exitosamente: {[a.name for a in launched_agents]}"
        )
        return launched_agents

    async def launch_agent(self, agent_name: str, resources: Dict = None) -> AgentInfo:
        """
        Lanza un solo agente

        Args:
            agent_name (str): Nombre del agente a lanzar
            resources (Dict, optional): Recursos a asignar al agente

        Returns:
            AgentInfo: Información del agente lanzado
        """

        # Obtiene un puerto disponible
        port = self.get_next_available_port()

        # Crea un registro para el agente con estado "starting"
        # el PID se actualizará despues de lanzar el proceso
        agent_info = AgentInfo(
            name=agent_name,
            pid=0,
            port=port,
            status=AgentStatus.STARTING,
            start_time=time.time(),
        )

        # Almacena el registro creado en el registro de la clase
        self.agent_registry[agent_info.id] = agent_info
        logger.debug(f"Creado registro para agente {agent_name} con ID {agent_info.id}")

        try:
            # Inicia el servicio pasando el ID del agente para que se incluya en los recursos
            pid, _ = await AgentService.start_agent(
                agent_name, port, resources, agent_id=agent_info.id
            )

            # Actualiza el registro con el PID real y estado "running"
            agent_info.pid = pid
            agent_info.status = AgentStatus.RUNNING
            logger.info(
                f"Agente {agent_name} iniciado correctamente con ID {agent_info.id}"
            )

            return agent_info
        except Exception as e:
            # En caso de error, actualizar estado a "error" y relanza excepción
            agent_info.status = AgentStatus.ERROR
            logger.error(f"Error al iniciar el agente {agent_name}: {e}")

            raise e

    async def stop_agent(
        self,
        agent_id: Optional[str] = None,
        agent_name: Optional[str] = None,
        pid: Optional[int] = None,
        port: Optional[int] = None,
    ) -> List[AgentInfo]:
        """
        Detiene uno o varios agentes según los criterios proporcionados
        puede detener uno o varios agentes si se juega con los criterios
        Ej: Port: Ag1, PID: Ag2. Aunque está pensado para detener solo uno

        Args:
            agent_id (Optional[str]): ID del agente
            agent_name (Optional[str]): Nombre del agente
            pid (Optional[int]): PID del proceso
            port (Optional[int]): Puerto del servicio

        Returns:
            List[AgentInfo]: Información del agente/s detenidos

        Raises:
            AgentNotFoundError: Si no se encuentra ningún agente que cumpla los criterios
        """

        # Comprueba que se haya proporcionado al menos un criterio
        if not any([agent_id, agent_name, pid, port]):
            logger.error("No se proporcionó ningún criterio para detener agentes")
            raise ValueError(
                "Debe proporcionar al menos un criterio para detener agentes"
            )

        agents_to_stop = []  # Lista de agentes pendientes de detener

        # Intenta buscar al agente, primero por ID, si no lo encuentra por nombre
        # PID o puerto. Si lo encuentra lo añade a la lista
        if agent_id is not None:
            if agent_id in self.agent_registry:
                agents_to_stop.append(agent_id)
                logger.debug(f"Agente encontrado por ID: {agent_id}")
        else:
            for a_id, info in list(self.agent_registry.items()):
                if (
                    (agent_name is not None and info.name == agent_name)
                    or (pid is not None and info.pid == pid)
                    or (port is not None and info.port == port)
                ):
                    agents_to_stop.append(a_id)
                    logger.debug(
                        f"Agente encontrado por criterios: {a_id} ({info.name})"
                    )

        # Verifica que se encontró al menos un agente
        if not agents_to_stop:
            # Crea un payload para enviar a la excepción con datos recibidos
            criteria = ", ".join(
                [
                    f"id={agent_id}" if agent_id else "",
                    f"name={agent_name}" if agent_name else "",
                    f"pid={pid}" if pid else "",
                    f"port={port}" if port else "",
                ]
            ).strip(", ")

            logger.warning(f"No se encontraron agentes con los criterios: {criteria}")
            raise AgentNotFoundError(criteria)

        stopped_agents = []  # Lista de agentes pendientes detenidos
        logger.info(f"Se detendrán {len(agents_to_stop)} agentes")

        # Detiene los agentes y devuelve la lista de agentes detenidos
        for a_id in agents_to_stop:
            agent_info = await self._stop_single_agent(a_id)
            stopped_agents.append(agent_info)

        return stopped_agents

    async def _stop_single_agent(self, agent_id: str) -> AgentInfo:
        """
        Detiene un solo agente por su ID

        Args:
            agent_id (str): ID del agente a detener

        Returns:
            AgentInfo: Información del agente detenido

        Raises:
            AgentShutdownError: Si hay un error al detener el agente
        """

        # Verifica que el agente existe en el registro de la clase
        if agent_id not in self.agent_registry:
            logger.error(f"Agente con ID {agent_id} no encontrado en el registro")
            raise AgentNotFoundError(f"id={agent_id}")

        # Obtene la información del agente
        agent_info = self.agent_registry[agent_id]
        logger.info(
            f"Deteniendo agente: {agent_info.name} (ID: {agent_id}, PID: {agent_info.pid}, Puerto: {agent_info.port})"
        )

        # Actualiza estado del agente a "stopping"
        agent_info.status = AgentStatus.STOPPING

        try:
            # Detiene el servicio
            success = await AgentService.stop_agent(
                agent_name=agent_info.name, port=agent_info.port, pid=agent_info.pid
            )

            # Si no puede detenerlo lanza una excepción
            if not success:
                logger.error(
                    f"No se pudo detener el agente {agent_info.name} (ID: {agent_id})"
                )
                raise AgentShutdownError(
                    agent_id=agent_id, details="No se pudo detener el servicio"
                )

            # Actualiza el estado del agente
            agent_info.status = AgentStatus.STOPPED

            # Añadir su puerto a la lista de puertos disponibles
            if agent_info.port >= settings.MIN_AGENT_PORT:
                # Solo añadir si no está ya en la lista
                if agent_info.port not in self.available_ports:
                    self.available_ports.append(agent_info.port)
                    # Ordenar la lista para usar siempre el puerto más bajo disponible
                    self.available_ports.sort()
                    logger.debug(
                        f"Puerto {agent_info.port} marcado como disponible para reutilización"
                    )

            # Elimina el agente del registro de la clase
            del self.agent_registry[agent_id]
            logger.info(f"Agente {agent_info.name} eliminado del registro")

            # Devuelve la información del agente eliminado
            return agent_info
        except Exception as e:
            # En caso de error, actualizar estado y relanza la excepción
            agent_info.status = AgentStatus.ERROR
            logger.error(f"Error durante el cierre del agente {agent_info.name}: {e}")

            # Si no es del tipo AgentShutdownError, la envuelve
            if not isinstance(e, AgentShutdownError):
                raise AgentShutdownError(agent_id=agent_id, details=str(e))

            raise e

    async def stop_all_agents(self) -> List[AgentInfo]:
        """
        Detiene todos los agentes en ejecución

        Returns:
            List[AgentInfo]: Información de los agentes detenidos
        """

        # Lista de agentes a detener
        stopped_agents = []
        agent_ids = list(self.agent_registry.keys())

        logger.info(f"Deteniendo {len(agent_ids)} agentes")

        for agent_id in agent_ids:
            try:
                agent_info = await self._stop_single_agent(agent_id)
                stopped_agents.append(agent_info)
            except Exception as e:
                logger.error(f"Error al detener agente {agent_id}: {str(e)}")

        logger.info(f"Se detuvieron {len(stopped_agents)} agentes en total")

        return stopped_agents

    def list_agents(
        self,
        status: Optional[Union[AgentStatus, str]] = None,
        agent_name: Optional[str] = None,
    ) -> List[AgentInfo]:
        """
        Lista agentes con filtros opcionales

        Args:
            status (Optional[Union[AgentStatus, str]]): Filtrar por estado
            agent_name (Optional[str]): Filtrar por nombre

        Returns:
            List[AgentInfo]: Lista de agentes que cumplen los criterios
        """

        # Convierte status a AgentStatus si es string
        if status and isinstance(status, str):
            try:
                status = AgentStatus(status)
                logger.debug(f"Convertido status string '{status}' a enum")
            except ValueError:
                # Si el estado no es válido, ignorar filtro
                logger.warning(f"Estado '{status}' no válido, ignorando filtro")
                status = None

        # Aplica filtros
        filtered_agents = list(self.agent_registry.values())
        total_agents = len(filtered_agents)

        if status:
            filtered_agents = [a for a in filtered_agents if a.status == status]
            logger.debug(
                f"Filtrado por status '{status}': {len(filtered_agents)}/{total_agents} agentes"
            )

        if agent_name:
            filtered_agents = [a for a in filtered_agents if a.name == agent_name]
            logger.debug(
                f"Filtrado por nombre '{agent_name}': {len(filtered_agents)}/{total_agents} agentes"
            )

        return filtered_agents


# Crea una instancia global de Agent Manager
agent_manager = AgentManager()
