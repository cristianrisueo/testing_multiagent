"""
Tests adicionales para aumentar la cobertura del módulo services.py.

Este archivo contiene pruebas unitarias enfocadas en:
- Casos de error y excepciones
- Flujos alternativos
- Comportamientos complejos con múltiples condiciones
- Manejo de manifiestos y recursos
"""

import pytest
import time
from unittest.mock import patch, MagicMock, mock_open
import requests
from src.services import AgentManager, AgentService
from src.models import (
    AgentInfo,
    AgentStatus,
    AgentStartupError,
)
from src.config import settings


@pytest.fixture
def agent_manager():
    """Fixture que proporciona una instancia de AgentManager."""

    return AgentManager()


@pytest.fixture
def agent_info():
    """Fixture que proporciona información de un agente para pruebas."""

    return AgentInfo(
        id="test-agent-id",
        name="test-agent",
        pid=12345,
        port=8002,
        status=AgentStatus.RUNNING,
        start_time=time.time(),
    )


@pytest.mark.asyncio
@patch("src.services.AgentService.start_agent")
async def test_ensure_orchestrator_running_new(mock_start_agent, agent_manager):
    """Test para asegurar que se inicia el orquestador si no existe."""

    # Configura el mock para start_agent
    mock_start_agent.return_value = (12345, "/path/to/service")

    # Llama al método ensure_orchestrator_running
    result = await agent_manager.ensure_orchestrator_running({"test": "resources"})

    # Verifica que se llamó a start_agent con los parámetros correctos
    # Verifica solo la llamada
    mock_start_agent.assert_called_once()
    args, kwargs = mock_start_agent.call_args

    assert args[0] == "orquestador"
    assert args[1] == settings.ORCHESTRATOR_PORT
    assert "agent_id" in kwargs

    # Verifica que el orquestador se registró correctamente
    assert result.name == "orquestador"
    assert result.pid == 12345
    assert result.status == AgentStatus.RUNNING
    assert agent_manager.orchestrator_agent_id == result.id


@pytest.mark.asyncio
async def test_ensure_orchestrator_running_existing(agent_manager):
    """Test para verificar que se reutiliza el orquestador si ya existe."""

    # Crea un orquestador existente
    orchestrator_info = AgentInfo(
        id="orchestrator-id",
        name="orquestador",
        pid=12345,
        port=settings.ORCHESTRATOR_PORT,
        status=AgentStatus.RUNNING,
        start_time=time.time(),
    )

    # Registra el orquestador
    agent_manager.agent_registry[orchestrator_info.id] = orchestrator_info
    agent_manager.orchestrator_agent_id = orchestrator_info.id

    # Llama al método ensure_orchestrator_running
    with patch("src.services.AgentService.start_agent") as mock_start:
        result = await agent_manager.ensure_orchestrator_running()

        # Verifica que no se llamó a start_agent
        mock_start.assert_not_called()

        # Verifica que se devolvió el orquestador existente
        assert result.id == orchestrator_info.id


@pytest.mark.asyncio
@patch("src.services.AgentService.stop_agent")
async def test_ensure_orchestrator_port_conflict(mock_stop_agent, agent_manager):
    """Test para verificar que se libera el puerto del orquestador si está ocupado."""

    # Crea un agente que está usando el puerto del orquestador
    conflicting_agent = AgentInfo(
        id="conflicting-id",
        name="conflicting-agent",
        pid=12346,
        port=settings.ORCHESTRATOR_PORT,
        status=AgentStatus.RUNNING,
        start_time=time.time(),
    )

    # Registra el agente conflictivo
    agent_manager.agent_registry[conflicting_agent.id] = conflicting_agent

    # Configura el mock para stop_agent
    mock_stop_agent.return_value = True

    # Configura el mock para start_agent
    with patch("src.services.AgentService.start_agent") as mock_start:
        mock_start.return_value = (12345, "/path/to/service")

        # Llama al método ensure_orchestrator_running
        await agent_manager.ensure_orchestrator_running()

        # Verifica que se llamó a stop_agent para el agente conflictivo
        mock_stop_agent.assert_called_once()


@pytest.mark.asyncio
@patch("src.services.AgentService.start_agent")
async def test_ensure_orchestrator_error(mock_start_agent, agent_manager):
    """Test para verificar el manejo de errores al iniciar el orquestador."""

    # Configura el mock para lanzar una excepción
    mock_start_agent.side_effect = Exception("Test error")

    # Llama al método ensure_orchestrator_running
    with pytest.raises(Exception):
        await agent_manager.ensure_orchestrator_running()

    # Verifica que el ID del orquestador se limpió
    assert agent_manager.orchestrator_agent_id is None


@pytest.mark.asyncio
@patch("src.services.AgentService.start_agent")
@patch("src.services.read_available_agents")
async def test_launch_agents_with_orchestrator(
    mock_read_agents, mock_start_agent, agent_manager
):
    """Test para verificar el lanzamiento de agentes con inicialización del orquestador."""

    # Configura mocks
    mock_read_agents.return_value = ["test-agent-1", "orquestador"]
    mock_start_agent.return_value = (12345, "/path/to/service")

    # Llama al método launch_agents
    _ = await agent_manager.launch_agents(["test-agent-1"], {"global": "resource"})

    # Verificamos que se realizaron al menos 2 llamadas
    assert mock_start_agent.call_count >= 2

    # Verificamos los elementos esenciales de cada llamada
    call_args_list = mock_start_agent.call_args_list

    # Buscamos llamadas por sus características principales
    orchestrator_call_found = False
    agent_call_found = False

    for call_obj in call_args_list:
        args, _ = call_obj
        if args[0] == "orquestador" and args[1] == settings.ORCHESTRATOR_PORT:
            orchestrator_call_found = True
        elif args[0] == "test-agent-1":
            agent_call_found = True

    assert orchestrator_call_found, "No se encontró llamada para iniciar el orquestador"
    assert (
        agent_call_found
    ), "No se encontró llamada para iniciar el agente test-agent-1"


@pytest.mark.asyncio
@patch("src.services.AgentService.stop_agent")
async def test_stop_agent_orchestrator_with_running_agents(
    mock_stop_agent, agent_manager
):
    """Test para verificar que no se puede detener el orquestador si hay agentes en ejecución."""

    # Configura el orquestador
    orchestrator_info = AgentInfo(
        id="orchestrator-id",
        name="orquestador",
        pid=12345,
        port=settings.ORCHESTRATOR_PORT,
        status=AgentStatus.RUNNING,
        start_time=time.time(),
    )

    # Configura un agente regular
    regular_agent = AgentInfo(
        id="regular-id",
        name="regular-agent",
        pid=12346,
        port=8002,
        status=AgentStatus.RUNNING,
        start_time=time.time(),
    )

    # Registra ambos agentes
    agent_manager.agent_registry[orchestrator_info.id] = orchestrator_info
    agent_manager.agent_registry[regular_agent.id] = regular_agent
    agent_manager.orchestrator_agent_id = orchestrator_info.id

    # Intenta detener el orquestador
    with pytest.raises(ValueError):
        await agent_manager.stop_agent(agent_id=orchestrator_info.id)

    # Verifica que no se llamó a stop_agent
    mock_stop_agent.assert_not_called()


@pytest.mark.asyncio
async def test_stop_agent_no_criteria(agent_manager):
    """Test para verificar el manejo de errores cuando no se proporciona ningún criterio."""

    # Intenta detener un agente sin proporcionar criterios
    with pytest.raises(ValueError):
        await agent_manager.stop_agent()


@pytest.mark.asyncio
@patch("src.services.requests.get")
@patch("src.services.subprocess.Popen")
async def test_agent_service_start_timeout(mock_popen, mock_requests_get):
    """Test para verificar el manejo de timeouts al iniciar un servicio."""

    # Configura el mock de Popen
    mock_process = MagicMock()
    mock_process.pid = 12345
    mock_process.communicate.return_value = (b"", b"")
    mock_popen.return_value = mock_process

    # Configura el mock de requests.get para simular timeout
    mock_requests_get.side_effect = requests.RequestException("Connection error")

    # Parches adicionales para evitar errores de archivo
    with patch("src.services.save_agent_resources", return_value="/tmp/mock.json"):
        with patch(
            "src.services.generate_agent_service_command", return_value=["echo", "test"]
        ):
            with patch("src.services.clean_agent_resources", return_value=True):
                # Configura un timeout más corto para la prueba
                original_timeout = settings.AGENT_STARTUP_TIMEOUT
                settings.AGENT_STARTUP_TIMEOUT = 0.1

                # Llama al método start_agent y espera una excepción
                with pytest.raises(AgentStartupError):
                    await AgentService.start_agent("test-agent", 8002)

                # Restaura el timeout original
                settings.AGENT_STARTUP_TIMEOUT = original_timeout

                # Verifica que se llamó a terminate para el proceso
                mock_process.terminate.assert_called_once()


@pytest.mark.asyncio
@patch("src.services.requests.get")
@patch("src.services.psutil.pid_exists")
async def test_agent_service_stop_graceful_shutdown(mock_pid_exists, mock_requests_get):
    """Test para verificar el apagado graceful de un servicio."""

    # Configura el mock de requests.get
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_requests_get.return_value = mock_response

    # Configura mock_pid_exists para simular que el proceso ya no existe
    mock_pid_exists.return_value = False

    # Parches adicionales
    with patch("src.services.clean_agent_resources", return_value=True):
        with patch("src.services.clean_agent_service_file", return_value=True):
            # Llama al método stop_agent
            result = await AgentService.stop_agent("test-agent", 8002, 12345)

            # Verifica que se llamó a requests.get con la URL correcta
            mock_requests_get.assert_called_once_with(
                "http://localhost:8002/shutdown", timeout=2
            )

            # Verifica que se verificó si el PID existe
            mock_pid_exists.assert_called_once_with(12345)

            # Verifica que el resultado es True
            assert result is True


@pytest.mark.asyncio
@patch("src.services.requests.get")
@patch("src.services.psutil.pid_exists")
@patch("src.services.os.kill")
async def test_agent_service_stop_forced_terminate(
    mock_os_kill, mock_pid_exists, mock_requests_get
):
    """Test para verificar el apagado forzado de un servicio."""

    # Configura el mock de requests.get
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_requests_get.return_value = mock_response

    # Configura mock_pid_exists para simular que el proceso sigue vivo
    mock_pid_exists.return_value = True

    # Parches adicionales
    with patch("src.services.clean_agent_resources", return_value=True):
        with patch("src.services.clean_agent_service_file", return_value=True):
            # Configura un timeout más corto para la prueba
            original_timeout = settings.AGENT_SHUTDOWN_TIMEOUT
            settings.AGENT_SHUTDOWN_TIMEOUT = 0.1

            # Llama al método stop_agent
            result = await AgentService.stop_agent("test-agent", 8002, 12345)

            # Restaura el timeout original
            settings.AGENT_SHUTDOWN_TIMEOUT = original_timeout

            # Verifica que se llamó a os.kill para terminar el proceso
            assert mock_os_kill.call_count >= 1

            # Verifica que el resultado es True
            assert result is True


@pytest.mark.asyncio
@patch("src.services.requests.get")
@patch("src.services.psutil.pid_exists")
@patch("src.services.os.kill")
async def test_agent_service_stop_http_error(
    mock_os_kill, mock_pid_exists, mock_requests_get
):
    """Test para verificar el manejo de errores HTTP al detener un servicio."""

    # Configura el mock de requests.get para lanzar una excepción
    mock_requests_get.side_effect = requests.RequestException("Connection error")

    # Configura mock_pid_exists para simular que el proceso ya no existe después del kill
    mock_pid_exists.return_value = False

    # Parches adicionales
    with patch("src.services.clean_agent_resources", return_value=True):
        with patch("src.services.clean_agent_service_file", return_value=True):
            # Llama al método stop_agent
            result = await AgentService.stop_agent("test-agent", 8002, 12345)

            # Verifica que se llamó a os.kill para terminar el proceso
            mock_os_kill.assert_called_once()

            # Verifica que el resultado es True
            assert result is True


@pytest.mark.asyncio
@patch("src.services.AgentService.start_agent")
async def test_launch_agent_for_orchestrator(mock_start_agent, agent_manager):
    """Test para lanzar un agente específicamente orquestador."""

    # Configure mock to return a PID and service path
    mock_start_agent.return_value = (12345, "/path/to/service")

    # Orchestrator should use fixed port
    agent_info = await agent_manager.launch_agent("orquestador")

    # Verify the orchestrator was configured correctly
    assert agent_info.name == "orquestador"
    assert agent_info.port == settings.ORCHESTRATOR_PORT
    assert agent_manager.orchestrator_agent_id == agent_info.id


@pytest.mark.asyncio
@patch("src.services.AgentService.start_agent")
async def test_launch_agent_error(mock_start_agent, agent_manager):
    """Test para verificar manejo de errores al lanzar un agente."""

    # Configure mock to raise an exception
    mock_start_agent.side_effect = Exception("Test launch error")

    # Call the launch_agent method and expect exception
    with pytest.raises(Exception):
        await agent_manager.launch_agent("test-agent")

    # Verify the agent has ERROR status rather than checking if it's in the registry
    # The agent is actually added to the registry with ERROR status
    assert len(agent_manager.agent_registry) == 1
    agent_id = list(agent_manager.agent_registry.keys())[0]
    assert agent_manager.agent_registry[agent_id].status == AgentStatus.ERROR


@pytest.mark.asyncio
@patch("src.services.clean_agent_resources")
@patch("src.services.generate_agent_service_command")
async def test_agent_service_start_error_handling(
    mock_generate_command, mock_clean_resources
):
    """Test para verificar el manejo integral de errores en start_agent."""

    # Configure mocks
    mock_generate_command.side_effect = Exception("Command generation error")
    mock_clean_resources.return_value = True

    # Save_agent_resources will be called but we need to mock it for resources
    with patch("src.services.save_agent_resources", return_value="/tmp/mock.json"):
        # Call start_agent and expect AgentStartupError
        with pytest.raises(AgentStartupError):
            await AgentService.start_agent("test-agent", 8002, {"test": "value"})

        # Verify cleanup was attempted
        mock_clean_resources.assert_called_once_with("test-agent", 8002)


@pytest.mark.asyncio
async def test_get_next_available_port(agent_manager):
    """Test para verificar la asignación correcta de puertos."""

    # Primera asignación: debe ser MIN_AGENT_PORT
    port1 = agent_manager.get_next_available_port()
    assert port1 == settings.MIN_AGENT_PORT

    # Segunda asignación: debe ser MIN_AGENT_PORT + 1
    port2 = agent_manager.get_next_available_port()
    assert port2 == settings.MIN_AGENT_PORT + 1

    # Añade un puerto a la lista de disponibles (simula un puerto liberado)
    agent_manager.available_ports.append(8010)

    # Tercera asignación: debe usar el puerto reutilizado
    port3 = agent_manager.get_next_available_port()
    assert port3 == 8010  # Puerto reutilizado
    assert agent_manager.available_ports == []  # Lista vacía después de usar el puerto


@pytest.mark.asyncio
@patch("src.services.AgentService.stop_agent")
async def test_stop_agent_multiple_match(mock_stop_agent, agent_manager):
    """Test para detener múltiples agentes que coinciden con el mismo criterio."""

    # Configura el mock para devolver True (detención exitosa)
    mock_stop_agent.return_value = True

    # Añade varios agentes con el mismo nombre
    for i in range(3):
        agent = AgentInfo(
            id=f"test-agent-id-{i}",
            name="same-name-agent",
            pid=12345 + i,
            port=8002 + i,
            status=AgentStatus.RUNNING,
            start_time=time.time(),
        )
        agent_manager.agent_registry[agent.id] = agent

    # Detiene los agentes por nombre
    stopped_agents = await agent_manager.stop_agent(agent_name="same-name-agent")

    # Verifica que se detuvieron todos los agentes
    assert len(stopped_agents) == 3
    assert all(agent.name == "same-name-agent" for agent in stopped_agents)
    assert len(agent_manager.agent_registry) == 0


@pytest.mark.asyncio
@patch(
    "src.services.AgentService.stop_agent", side_effect=Exception("Error al detener")
)
async def test_stop_all_agents_with_errors(mock_stop_agent, agent_manager):
    """Test para verificar el manejo de errores al detener todos los agentes."""

    # Añade agentes al registro
    agent1 = AgentInfo(
        id="test-agent-id-1",
        name="test-agent-1",
        pid=12345,
        port=8002,
        status=AgentStatus.RUNNING,
        start_time=time.time(),
    )
    agent2 = AgentInfo(
        id="test-agent-id-2",
        name="test-agent-2",
        pid=12346,
        port=8003,
        status=AgentStatus.RUNNING,
        start_time=time.time(),
    )

    agent_manager.agent_registry[agent1.id] = agent1
    agent_manager.agent_registry[agent2.id] = agent2

    # Intenta detener todos los agentes
    stopped_agents = await agent_manager.stop_all_agents()

    # Verifica que no se devolvió ningún agente detenido pero el método no lanzó excepción
    assert len(stopped_agents) == 0
    assert mock_stop_agent.call_count == 2  # Se intentó detener ambos agentes


# Nuevas pruebas para manejo de manifiestos y recursos subidos al agente


@pytest.mark.asyncio
async def test_launch_agent_with_resources_validation(agent_manager):
    """
    Test para verificar que los recursos del manifiesto se validan correctamente.

    Verifica que los recursos se pasan correctamente al lanzar un agente.
    """

    # Configurar mock para start_agent
    with patch("src.services.AgentService.start_agent") as mock_start_agent:
        mock_start_agent.return_value = (12345, "/path/to/service")

        # Recursos para probar
        resources = {
            "database": {
                "host": "localhost",
                "port": 5432,
                "credentials": {"username": "test_user", "password": "test_password"},
            },
            "api_keys": ["key1", "key2", "key3"],
            "timeout": 30,
            "retries": 3,
        }

        # Lanza el agente con recursos
        await agent_manager.launch_agent("test-agent", resources)

        # Verifica que start_agent fue llamado con los argumentos correctos
        mock_start_agent.assert_called_once()
        args, _ = mock_start_agent.call_args

        # Verifica que los argumentos son correctos
        assert args[0] == "test-agent"

        # En lugar de verificar kwargs, verifica que se pasaron los recursos
        # como el tercer argumento, los recursos
        assert len(args) >= 3
        assert args[2] == resources


@pytest.mark.asyncio
async def test_save_agent_resources_format_validation(monkeypatch):
    """
    Test para verificar que la función save_agent_resources guarda los recursos en el formato correcto.
    """

    # Configura los mocks
    with patch("builtins.open", mock_open()) as mock_file, patch(
        "json.dump"
    ) as mock_json_dump:

        # Configura path para que exista
        monkeypatch.setattr("src.utils.Path.exists", lambda _: True)

        # Importar la función directamente
        from src.utils import save_agent_resources

        agent_name = "test-agent"
        port = 8002
        agent_id = "test-agent-id"
        resources = {"key1": "value1", "key2": 2, "nested": {"subkey": "subvalue"}}

        # Llama a la función
        _ = save_agent_resources(agent_name, port, resources, agent_id)

        # Verifica que se abrió el archivo correcto
        mock_file.assert_called_once()

        # Verifica que se guardaron los recursos correctos
        mock_json_dump.assert_called_once()

        saved_resources = mock_json_dump.call_args[0][0]  # Primer argumento posicional

        # Verifica que se añadió la información adicional
        assert saved_resources["agent_id"] == agent_id
        assert saved_resources["agent_name"] == agent_name

        # Verifica que se conservaron los recursos originales
        assert saved_resources["key1"] == "value1"
        assert saved_resources["key2"] == 2
        assert saved_resources["nested"]["subkey"] == "subvalue"


@pytest.mark.asyncio
async def test_save_agent_resources_invalid_format(monkeypatch):
    """
    Test para verificar que save_agent_resources maneja correctamente recursos con formato inválido.

    Verifica que cuando los recursos no pueden convertirse a JSON, se lanza
    una excepción apropiada.
    """

    # Configura los mocks
    with patch("builtins.open", mock_open()) as _, patch(
        "json.dump", side_effect=Exception("JSON format error")
    ):

        # Configura path para que exista
        monkeypatch.setattr("src.utils.Path.exists", lambda _: True)

        # Importa la función directamente para la prueba
        from src.utils import save_agent_resources

        agent_name = "test-agent"
        port = 8002

        # Recursos con valores no serializables
        class NonSerializable:
            pass

        resources = {"key": NonSerializable()}

        # Verifica que se lanza una excepción
        with pytest.raises(IOError):
            save_agent_resources(agent_name, port, resources)


@pytest.mark.asyncio
async def test_launch_agents_with_specific_resources(agent_manager):
    """
    Test para verificar que los recursos específicos de agente tienen prioridad.

    Verifica que cuando se proporcionan recursos globales y específicos de agente,
    los específicos tienen prioridad sobre los globales.
    """

    # Configura los mocks
    with patch("src.services.read_available_agents") as mock_read_agents, patch.object(
        agent_manager, "launch_agent"
    ) as mock_launch_agent, patch.object(
        agent_manager, "ensure_orchestrator_running"
    ) as mock_ensure_orch:

        mock_read_agents.return_value = ["test-agent-1", "test-agent-2"]
        mock_launch_agent.return_value = AgentInfo(
            id="test-id",
            name="test-agent-1",
            pid=12345,
            port=8002,
            status=AgentStatus.RUNNING,
            start_time=time.time(),
        )
        mock_ensure_orch.return_value = None

        # Crea recursos globales y específicos de agente
        resources = {
            "global_key": "global_value",
            "common_key": "global_common",
            "test-agent-1": {
                "specific_key": "specific_value",
                "common_key": "agent_specific_common",  # Debería tener prioridad
            },
        }

        # Lanza los agentes
        await agent_manager.launch_agents(["test-agent-1"], resources)

        # Verifica que se llamó a launch_agent con los recursos correctos
        mock_launch_agent.assert_called_once()
        args, _ = mock_launch_agent.call_args

        agent_name = args[0]
        agent_resources = args[1]

        # Verifica que los recursos específicos tienen prioridad
        assert agent_name == "test-agent-1"
        assert "global_key" in agent_resources
        assert agent_resources["global_key"] == "global_value"
        assert "specific_key" in agent_resources
        assert agent_resources["specific_key"] == "specific_value"
        assert agent_resources["common_key"] == "agent_specific_common"


@pytest.mark.asyncio
async def test_manifest_storage_and_cleanup():
    """
    Test para verificar el ciclo completo de almacenamiento y limpieza de manifiestos.

    Verifica que los manifiestos se almacenan correctamente y se limpian
    cuando se detiene el agente.
    """

    # Datos de prueba
    agent_name = "test-agent"
    port = 8002
    agent_id = "test-id"
    resources = {"config": {"timeout": 30, "retries": 3}}

    # Configura los mocks
    with patch("builtins.open", mock_open()) as mock_file, patch(
        "src.utils.Path.exists"
    ) as mock_exists, patch("src.utils.Path.unlink") as mock_unlink, patch(
        "json.dump"
    ) as mock_json_dump, patch(
        "json.load", return_value={"test_key": "test_value"}
    ):

        mock_exists.return_value = True

        # Importa funciones directamente para la prueba
        from src.utils import save_agent_resources, clean_agent_resources

        # Guarda los recursos
        _ = save_agent_resources(agent_name, port, resources, agent_id)

        # Comprueba que se abrió el archivo para escritura
        mock_file.assert_called()

        # Comprueba que se guardó el JSON correctamente
        mock_json_dump.assert_called_once()

        # 2. Comprueba recursos
        result = clean_agent_resources(agent_name, port)

        # VerifiCompruebacar que se eliminó el archivo
        assert result is True
        mock_unlink.assert_called_once()


@pytest.mark.asyncio
async def test_agent_service_with_complex_resources():
    """
    Test para verificar el manejo de recursos complejos en start_agent.

    Verifica que start_agent puede manejar recursos complejos y anidados
    correctamente.
    """

    # Recursos complejos para probar
    complex_resources = {
        "database": {
            "host": "db.example.com",
            "port": 5432,
            "credentials": {"username": "test_user", "password": "test_password"},
        },
        "features": {
            "enabled": ["search", "indexing", "notification"],
            "disabled": ["billing", "reports"],
        },
        "limits": {
            "connections": 100,
            "requests_per_minute": 1000,
            "quotas": {"storage": "10GB", "bandwidth": "100GB"},
        },
    }

    # Configura los mocks
    with patch("src.services.subprocess.Popen") as mock_popen, patch(
        "src.services.requests.get"
    ) as mock_requests_get, patch(
        "src.services.save_agent_resources"
    ) as mock_save_resources, patch(
        "src.services.generate_agent_service_command"
    ) as mock_generate_command:

        # Configura mocks para simular un arranque exitoso
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_requests_get.return_value = mock_response

        mock_save_resources.return_value = "/tmp/resources.json"
        mock_generate_command.return_value = ["echo", "test"]

        mock_process = MagicMock()
        mock_process.pid = 12345
        mock_process.communicate.return_value = (b"", b"")
        mock_popen.return_value = mock_process

        # Inicia el agente con recursos complejos
        pid, _ = await AgentService.start_agent(
            "test-agent", 8002, complex_resources, "test-id"
        )

        # Comprueba que se llamó a save_agent_resources con los recursos complejos
        mock_save_resources.assert_called_once_with(
            "test-agent", 8002, complex_resources, "test-id"
        )

        # Comprueba que se inició el proceso correctamente
        assert pid == 12345
