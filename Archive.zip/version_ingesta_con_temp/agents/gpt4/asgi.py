"""
Servicio del agente GPT4.

Este agente proporciona capacidades de generación de texto utilizando GPT-4.
"""

import uvicorn
from fastapi import FastAPI, BackgroundTasks
import os
import time
import json
from pathlib import Path
from loguru import logger

# Configurar logger
logger.add(f"logs/agent_gpt4_{{AGENT_PORT}}.log", rotation="10 MB", level="INFO")

# Variables de configuración que serán reemplazadas
AGENT_PORT = {{AGENT_PORT}}  # Será reemplazado como entero (sin comillas)

# Crea la aplicación y registra el tiempo de inicio del servicio
app = FastAPI(title="GPT4 Agent Service")
start_time = time.time()


def get_resources():
    """
    Busca el fichero con los resources para este microservicio
    Si lo encuentra lo devuelve en la respuesta de la petición
    """

    try:
        resources_file = Path(f"agents/gpt4/manifest_resources_{AGENT_PORT}.json")

        if resources_file.exists():
            with open(resources_file, "r") as f:
                return json.load(f)

        return {}
    except Exception as e:
        logger.error(f"Error al obtener recursos: {e}")
        return {}


def shutdown_server():
    """
    Realiza un graceful shutdown del servidor
    Espera 1 segundo antes de cerrar para permitir que la respuesta
    HTTP sea enviada al cliente y termina el proceso
    """

    logger.info(f"Cerrando servicio del agente gpt4 en puerto {AGENT_PORT}")
    time.sleep(1)
    os._exit(0)


@app.get("/")
def read_root():
    """
    Endpoint raíz que identifica el servicio
    """

    logger.debug(f"Solicitud recibida en endpoint raíz del agente gpt4")
    return {"message": f"Soy el agente gpt4 iniciado en el puerto {AGENT_PORT}"}


@app.get("/status")
def status():
    """Proporciona información sobre el estado del servicio."""

    uptime = time.time() - start_time
    logger.debug(f"Solicitud de estado recibida. Uptime: {uptime:.2f} segundos")
    return {
        "status": "running",
        "agent": "gpt4",
        "port": AGENT_PORT,
        "pid": os.getpid(),
        "uptime_seconds": uptime,
    }


@app.get("/shutdown")
def shutdown(background_tasks: BackgroundTasks):
    """Inicia el proceso de apagado controlado del servicio."""

    logger.info(f"Solicitud de cierre recibida para agente gpt4")
    background_tasks.add_task(shutdown_server)

    return {"message": "Servicio cerrándose..."}


if __name__ == "__main__":
    logger.info(f"Iniciando agente gpt4 en puerto {AGENT_PORT}")
    uvicorn.run(app, host="0.0.0.0", port=AGENT_PORT)
