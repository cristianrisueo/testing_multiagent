"""
Servicio del agente Kendra.

Este agente proporciona capacidades de búsqueda y recuperación de información.
"""

import uvicorn
from fastapi import FastAPI, BackgroundTasks
import os
import time
import json
from pathlib import Path
from loguru import logger

# Configurar logger
logger.add(f"logs/agent_kendra_{{AGENT_PORT}}.log", rotation="10 MB", level="INFO")

# Variables de configuración que serán reemplazadas
AGENT_PORT = {{AGENT_PORT}}  # Será reemplazado como entero (sin comillas)

# Crea la aplicación y registra el tiempo de inicio del servicio
app = FastAPI(title="Kendra Agent Service")
start_time = time.time()


def get_resources():
    """
    Busca el fichero con los resources para este microservicio
    Si lo encuentra lo devuelve en la respuesta de la petición
    """

    try:
        resources_file = Path(f"agents/kendra/manifest_resources_{AGENT_PORT}.json")

        if resources_file.exists():
            with open(resources_file, "r") as f:
                return json.load(f)

        return {}
    except Exception as e:
        logger.error(f"Error al obtener recursos: {e}")
        return {}


def shutdown_server():
    """
    Realiza un graceful shutdown del servidor
    Espera 1 segundo antes de cerrar para permitir que la respuesta
    HTTP sea enviada al cliente y termina el proceso
    """

    logger.info(f"Cerrando servicio del agente kendra en puerto {AGENT_PORT}")
    time.sleep(1)
    os._exit(0)


@app.get("/")
def read_root():
    """
    Endpoint raíz que identifica el servicio
    """

    logger.debug(f"Solicitud recibida en endpoint raíz del agente kendra")
    return {"message": f"Soy el agente kendra iniciado en el puerto {AGENT_PORT}"}


@app.get("/status")
def status():
    """Proporciona información sobre el estado del servicio."""

    uptime = time.time() - start_time
    logger.debug(f"Solicitud de estado recibida. Uptime: {uptime:.2f} segundos")
    return {
        "status": "running",
        "agent": "kendra",
        "port": AGENT_PORT,
        "pid": os.getpid(),
        "uptime_seconds": uptime,
    }


@app.get("/shutdown")
def shutdown(background_tasks: BackgroundTasks):
    """Inicia el proceso de apagado controlado del servicio."""

    logger.info(f"Solicitud de cierre recibida para agente kendra")
    background_tasks.add_task(shutdown_server)

    return {"message": "Servicio cerrándose..."}


if __name__ == "__main__":
    logger.info(f"Iniciando agente kendra en puerto {AGENT_PORT}")
    uvicorn.run(app, host="0.0.0.0", port=AGENT_PORT)
