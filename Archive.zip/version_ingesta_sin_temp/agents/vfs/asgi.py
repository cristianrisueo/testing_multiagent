"""
Servicio del agente VFS.

Este agente proporciona funcionalidad de sistema de archivos virtual.
"""

import uvicorn
from fastapi import FastAPI, BackgroundTasks
import os
import time
import json
from pathlib import Path

# Puerto fijo del agente - debe definirse ANTES de usarse en el logger
AGENT_PORT = 8001

# Crea la aplicación y registra el tiempo de inicio del servicio
app = FastAPI(title="VFS Agent Service")
start_time = time.time()


def get_resources():
    """
    Busca el fichero con los resources para este microservicio
    Si lo encuentra lo devuelve en la respuesta de la petición
    """
    try:
        resources_file = Path(f"manifest_resources_{AGENT_PORT}.json")

        if resources_file.exists():
            with open(resources_file, "r") as f:
                return json.load(f)

        return {}
    except Exception as e:
        return {}


def shutdown_server():
    """
    Realiza un graceful shutdown del servidor
    Espera 1 segundo antes de cerrar para permitir que la respuesta
    HTTP sea enviada al cliente y termina el proceso
    """

    time.sleep(1)
    os._exit(0)


@app.get("/")
def read_root():
    """
    Endpoint raíz que identifica el servicio
    """

    return {"message": f"Soy el agente vfs iniciado en el puerto {AGENT_PORT}"}


@app.get("/status")
def status():
    """Proporciona información sobre el estado del servicio."""
    uptime = time.time() - start_time

    return {
        "status": "running",
        "agent": "vfs",
        "port": AGENT_PORT,
        "pid": os.getpid(),
        "uptime_seconds": uptime,
    }


@app.get("/shutdown")
def shutdown(background_tasks: BackgroundTasks):
    """Inicia el proceso de apagado controlado del servicio."""

    background_tasks.add_task(shutdown_server)
    return {"message": "Servicio cerrándose..."}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=AGENT_PORT)
