import os
from pydantic_settings import BaseSettings
from pathlib import Path


# Obtiene el directorio base del proyecto
BASE_DIR = Path(__file__).resolve().parent


class Settings(BaseSettings):
    """
    Configuración centralizada de la aplicación utilizando Pydantic BaseSettings.

    Esta clase gestiona todos los parámetros configurables del sistema, incluyendo:
    - Configuración general (nombre de la aplicación, modo debug)
    - Rangos de puertos para la API principal y los servicios de agentes
    - Rutas de archivos y directorios para datos persistentes
    - Timeouts y otros parámetros operativos

    Los valores se cargan con el siguiente orden de prioridad:
    1. Variables de entorno
    2. Archivo .env
    3. Valores predeterminados definidos en la clase

    Ejemplo de uso:
        settings = Settings()
        app = FastAPI(title=settings.APP_NAME)
        data_path = settings.DATA_DIR / "custom_file.json"
    """

    # Configuración general
    APP_NAME: str = "Generative AI Agent Manager"
    DEBUG: bool = os.getenv("DEBUG", "False").lower() == "true"

    # Configuración de puertos
    PORT: int = int(os.getenv("PORT", "8000"))
    MIN_AGENT_PORT: int = 8001
    MAX_AGENT_PORT: int = 12001

    # Directorios y archivos
    DATA_DIR: Path = BASE_DIR / "data"
    AGENTS_FILE: Path = DATA_DIR / "agents"
    TEMP_DIR: Path = BASE_DIR / "temp"

    # Configuración de agentes
    AGENT_STARTUP_TIMEOUT: int = 20  # segundos para iniciar un agente
    AGENT_SHUTDOWN_TIMEOUT: int = 10  # segundos para cerrar un agente

    # Clase añadida que configura el comportamiento de Pydantic para env
    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()  # Instancia la configuración
