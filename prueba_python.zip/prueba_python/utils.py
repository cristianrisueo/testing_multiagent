import os
from pathlib import Path
from typing import List
from config import settings


def ensure_directories() -> None:
    """
    Asegura que existen las carpetas y archivos necesarios para la aplicación.

    Crea:
    - El directorio de datos
    - El archivo de agentes con valores por defecto
    - El directorio temporal para los servicios de agentes
    """

    # Crea los directorios necesarios si no existe
    settings.DATA_DIR.mkdir(exist_ok=True, parents=True)
    settings.TEMP_DIR.mkdir(exist_ok=True, parents=True)

    # Crea archivo de agentes permitidos con valores por defecto si no existe
    if not settings.AGENTS_FILE.exists():
        with open(settings.AGENTS_FILE, "w") as f:
            f.write("vfs\nkendra\n")


def read_available_agents() -> List[str]:
    """
    Lee los agentes disponibles del archivo de configuración de agentes.

    Returns:
        List[str]: Lista de nombres de agentes disponibles

    Note:
        Si el archivo no existe, se creará automáticamente con valores predeterminados.
    """

    # Lee los agentes disponibles del archivo. Si no existe lo crea
    try:
        with open(settings.AGENTS_FILE, "r") as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        ensure_directories()
        return read_available_agents()


def generate_agent_service_file(agent_name: str, port: int) -> str:
    """
    Genera un archivo temporal con el código del servicio del agente.

    Args:
        agent_name (str): Nombre del agente
        port (int): Puerto para el servicio

    Returns:
        str: Ruta al archivo generado
    """

    # Se asegura que existe el directorio temporal
    settings.TEMP_DIR.mkdir(exist_ok=True, parents=True)

    # Ruta al fichero de plantilla de agentes
    template_path = Path(__file__).parent / "agents_template" / "main.py"

    try:
        # Lee la plantilla
        with open(template_path, "r") as f:
            template_content = f.read()

        # Reemplaza los marcadores
        content = template_content.replace("{{AGENT_NAME}}", agent_name)
        content = content.replace("{{AGENT_PORT}}", str(port))

        # Crea un archivo para el nuevo servicio y con los datos de la plantilla
        service_file = settings.TEMP_DIR / f"agent_service_{port}.py"
        with open(service_file, "w") as f:
            f.write(content)
        
        # Devuelve la ruta al fichero del nuevo servicio
        return str(service_file)
    except Exception as e:
        raise IOError(f"Error al generar el archivo del servicio: {str(e)}")


def clean_agent_service_file(port: int) -> bool:
    """
    Elimina el archivo temporal del servicio del agente.

    Args:
        port (int): Puerto del servicio cuyo archivo debe eliminarse

    Returns:
        bool: True si se eliminó correctamente, False si no existía o hubo un error
    """

    # Busca el fichero en el directorio temporal de agentes. Si lo encuentra lo elimina
    # y devuelve Trye. Si no devuelve False
    try:
        service_file = settings.TEMP_DIR / f"agent_service_{port}.py"

        if service_file.exists():
            service_file.unlink()

            return True

        return False
    except Exception:
        # Ante error de limpieza devuelve false
        return False
