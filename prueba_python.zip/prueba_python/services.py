import subprocess
import time
import requests
import os
import sys
import signal
import psutil
import asyncio
from typing import Dict, List, Tuple, Optional, Union
from config import settings
from utils import (
    read_available_agents,
    generate_agent_service_file,
    clean_agent_service_file,
)
from models import (
    AgentInfo,
    AgentStatus,
    AgentNotAvailableError,
    AgentStartupError,
    AgentNotFoundError,
    AgentShutdownError,
)


class AgentService:
    """
    Servicio responsable de la creación y eliminación de agentes individuales.

    Esta clase implementa las operaciones de bajo nivel necesarias para:
    - Iniciar un nuevo proceso para un agente en un puerto específico
    - Verificar que el servicio esté respondiendo correctamente
    - Realizar un apagado controlado de los procesos
    - Gestionar recursos temporales como archivos de servicio

    Actúa como una capa de abstracción entre el gestor de agentes (AgentManager) y
    los procesos del sistema operativo, encapsulando los detalles de implementación
    relacionados con la ejecución y comunicación con los procesos individuales.
    En el fondo son métodos estáticos, están actuándo como funciones puras.
    """

    @staticmethod
    async def start_agent(agent_name: str, port: int) -> Tuple[int, str]:
        """
        Inicia un nuevo servicio para el agente en el puerto especificado con más logs de depuración

        Args:
            agent_name (str): Nombre del agente
            port (int): Puerto para el servicio

        Returns:
            Tuple[int, str]: PID del proceso y ruta al archivo del servicio

        Raises:
            AgentStartupError: Si hay un error al iniciar el servicio
        """

        # Genera un archivo temporal del servicio iniciado
        service_file = generate_agent_service_file(agent_name, port)

        print(f"---------------------------------------------")
        print(f"Generando archivo de servicio: {service_file}")

        try:
            # Inicia el proceso y guarda el PID
            print(f"Iniciando servicio para {agent_name} en puerto {port}")
            process = subprocess.Popen(
                [sys.executable, service_file],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            pid = process.pid

            # Captura la salida temprana del proceso para diagnosticar problemas
            try:
                stdout, stderr = process.communicate(timeout=2)
                if stdout:
                    print(f"Salida estándar: {stdout.decode('utf-8')}")
                if stderr:
                    print(f"Error de inicio: {stderr.decode('utf-8')}")
            except subprocess.TimeoutExpired:
                print("Proceso iniciado correctamente")

            # Espera a que el servicio esté disponible
            service_ready = False
            start_time = time.time()

            # Intenta hacer una solicitud al endpoint de check del estado del servicio
            while (
                not service_ready
                and time.time() - start_time < settings.AGENT_STARTUP_TIMEOUT
            ):
                try:
                    print(f"Intentando conectar a http://localhost:{port}/status")
                    response = requests.get(
                        f"http://localhost:{port}/status", timeout=1
                    )

                    print(f"Status de la respuesta: {response.status_code}")
                    print(f"Contenido de la respuesta: {response.text}")
                    print(f"---------------------------------------------\n")

                    if response.status_code == 200:
                        service_ready = True
                    else:
                        await asyncio.sleep(0.5)
                except (requests.RequestException, ConnectionError) as e:
                    print(f"Error de conexión: {e}")
                    await asyncio.sleep(0.5)

            # Si no puede llamar al endpoint del servicio elimina el proceso y lanza una excepción
            if not service_ready:
                try:
                    process.terminate()
                    process.wait(timeout=3)
                except:
                    pass
                raise AgentStartupError(
                    agent_name=agent_name,
                    details=f"El servicio no respondió en {settings.AGENT_STARTUP_TIMEOUT} segundos",
                )

            # Si todo va bien devuelve el PID y el fichero con la info del servicio
            return pid, service_file
        except Exception as e:
            print(f"💥 Error crítico de inicio: {e}")
            raise AgentStartupError(agent_name=agent_name, details=str(e))

    @staticmethod
    async def stop_agent(port: int, pid: int) -> bool:
        """
        Detiene un servicio de agente. Intenta hacer un graceful shutdown y si falla mata el
        proceso directamente

        Args:
            port (int): Puerto del servicio
            pid (int): PID del proceso

        Returns:
            bool: True si se detuvo correctamente, False en caso contrario
        """

        try:
            # Llama al endpoint del agente para detener el servicio con un graceful shutdown
            # y guarda el tiempo de la ejecución
            requests.get(f"http://localhost:{port}/shutdown", timeout=2)
            start_time = time.time()

            # Comprueba si el proceso sigue vivo
            while time.time() - start_time < settings.AGENT_SHUTDOWN_TIMEOUT:
                try:
                    if not psutil.pid_exists(pid):
                        return True
                except:
                    return True  # Si hay un error al comprobar si el proceso sigue vivo asume que no existe

                await asyncio.sleep(0.5)

            # Si el proceso sigue vivo después del timeout, lo mata (cierra el servicio del agente a la fuerza)
            try:
                os.kill(pid, signal.SIGTERM)
                await asyncio.sleep(1)

                if psutil.pid_exists(pid):
                    os.kill(pid, signal.SIGKILL)

                return True
            except:
                return False
        except requests.RequestException:
            # Si falla la solicitud HTTP, intenta matar el proceso directamente
            try:
                os.kill(pid, signal.SIGTERM)
                await asyncio.sleep(1)

                if psutil.pid_exists(pid):
                    os.kill(pid, signal.SIGKILL)

                return True
            except:
                return False


class AgentManager:
    """
    Controlador central que coordina y administra el ciclo de vida completo de todos los agentes.

    Esta clase actúa como un orquestador y registro central, responsable de:
    - Mantener un inventario actualizado de todos los agentes en ejecución y sus estados
    - Asignar puertos disponibles para nuevos servicios de agentes
    - Validar la disponibilidad de agentes solicitados contra el catálogo de agentes permitidos
    - Lanzar múltiples agentes en paralelo y supervisar su estado
    - Proporcionar operaciones de filtrado y búsqueda para localizar agentes específicos
    - Coordinar el apagado ordenado de servicios activos durante el cierre del sistema
    - Manejar la recuperación ante fallos y garantizar la limpieza de recursos

    Funciona como la capa intermedia entre la API REST y los servicios de agentes individuales,
    aislando la lógica de negocio de los detalles de implementación del sistema operativo.
    """

    def __init__(self):
        """
        Constructor del gestor de agentes
        Establece el puerto y agentInfo (nombre del archivo temporal)
        """
        self.agent_registry: Dict[str, AgentInfo] = {}
        self.last_assigned_port = settings.MIN_AGENT_PORT - 1

    def get_next_available_port(self) -> int:
        """
        Obtiene el siguiente puerto disponible

        Returns:
            int: Número de puerto disponible
        """

        # Obtiene e incrementa el último puerto disponible
        self.last_assigned_port += 1

        # Verifica si el puerto ya está en uso o está fuera del rango permitido si lo
        # está incrementa el puerto de nuevo hasta alcanzar el último y lo sobrescribe
        while (
            self.last_assigned_port
            in [agent.port for agent in self.agent_registry.values()]
            or self.last_assigned_port > settings.MAX_AGENT_PORT
        ):
            self.last_assigned_port += 1
            if self.last_assigned_port > settings.MAX_AGENT_PORT:
                self.last_assigned_port = settings.MIN_AGENT_PORT

        # Devuelve el puerto incrementado o sobrescrito
        return self.last_assigned_port

    async def launch_agents(self, agent_names: List[str]) -> List[AgentInfo]:
        """
        Lanza múltiples agentes

        Args:
            agent_names (List[str]): Lista de nombres de agentes a lanzar

        Returns:
            List[AgentInfo]: Información de los agentes lanzados

        Raises:
            AgentNotAvailableError: Si algún agente no está disponible
        """

        # Verifica si el agente está disponible
        available_agents = read_available_agents()

        # Si algún agente no se encuetra disponible lanza excepción
        for agent_name in agent_names:
            if agent_name not in available_agents:
                raise AgentNotAvailableError(agent_name)

        # Si todos los agentes se encuetran disponibles los lanza
        # y guarda su información en la lista
        launched_agents = []
        for agent_name in agent_names:
            agent_info = await self.launch_agent(agent_name)
            launched_agents.append(agent_info)

        # Devuelve la lista con la información de los agentes
        return launched_agents

    async def launch_agent(self, agent_name: str) -> AgentInfo:
        """
        Lanza un solo agente

        Args:
            agent_name (str): Nombre del agente a lanzar

        Returns:
            AgentInfo: Información del agente lanzado
        """

        # Obtiene el puerto disponible
        port = self.get_next_available_port()

        # Crea un registro para el agente con estado "starting"
        # el PID se actualizará despues de lanzar el proceso
        agent_info = AgentInfo(
            name=agent_name,
            pid=0,
            port=port,
            status=AgentStatus.STARTING,
            start_time=time.time(),
        )

        # Almacena el registro creado en el registro de la clase
        self.agent_registry[agent_info.id] = agent_info

        try:
            # Inicia el servicio
            pid, _ = await AgentService.start_agent(agent_name, port)

            # Actualiza el registro con el PID real y estado "running"
            agent_info.pid = pid
            agent_info.status = AgentStatus.RUNNING

            return agent_info
        except Exception as e:
            # En caso de error, actualizar estado a "error" y relanza excepción
            agent_info.status = AgentStatus.ERROR
            raise e

    async def stop_agent(
        self,
        agent_id: Optional[str] = None,
        agent_name: Optional[str] = None,
        pid: Optional[int] = None,
        port: Optional[int] = None,
    ) -> List[AgentInfo]:
        """
        Detiene uno o varios agentes según los criterios proporcionados
        puede detener uno o varios agentes si se juega con los criterios
        Ej: Port: Ag1, PID: Ag2. Aunque está pensado para detener solo uno

        Args:
            agent_id (Optional[str]): ID del agente
            agent_name (Optional[str]): Nombre del agente
            pid (Optional[int]): PID del proceso
            port (Optional[int]): Puerto del servicio

        Returns:
            List[AgentInfo]: Información del agente/s detenidos

        Raises:
            AgentNotFoundError: Si no se encuentra ningún agente que cumpla los criterios
        """

        # Verifica que se haya proporcionado al menos un criterio
        if not any([agent_id, agent_name, pid, port]):
            raise ValueError(
                "Debe proporcionar al menos un criterio para detener agentes"
            )

        agents_to_stop = []  # Lista de agentes pendientes de detener

        # Intenta buscar al agente, primero por ID, si no lo encuentra por nombre
        # PID o puerto. Si lo encuentra lo añade a la lista
        if agent_id is not None:
            if agent_id in self.agent_registry:
                agents_to_stop.append(agent_id)
        else:
            for a_id, info in list(self.agent_registry.items()):
                if (
                    (agent_name is not None and info.name == agent_name)
                    or (pid is not None and info.pid == pid)
                    or (port is not None and info.port == port)
                ):
                    agents_to_stop.append(a_id)

        # Verifica que se encontró al menos un agente
        if not agents_to_stop:
            # Crea un payload para enviar a la excepción con datos recibidos
            criteria = ", ".join(
                [
                    f"id={agent_id}" if agent_id else "",
                    f"name={agent_name}" if agent_name else "",
                    f"pid={pid}" if pid else "",
                    f"port={port}" if port else "",
                ]
            ).strip(", ")

            raise AgentNotFoundError(criteria)

        stopped_agents = []  # Lista de agentes pendientes detenidos

        # Detiene los agentes y devuelve la lista de agentes detenidos
        for a_id in agents_to_stop:
            agent_info = await self._stop_single_agent(a_id)
            stopped_agents.append(agent_info)

        return stopped_agents

    async def _stop_single_agent(self, agent_id: str) -> AgentInfo:
        """
        Detiene un solo agente por su ID

        Args:
            agent_id (str): ID del agente a detener

        Returns:
            AgentInfo: Información del agente detenido

        Raises:
            AgentShutdownError: Si hay un error al detener el agente
        """

        # Verifica que el agente existe en el registro de la clase
        if agent_id not in self.agent_registry:
            raise AgentNotFoundError(f"id={agent_id}")

        # Obtene la información del agente
        agent_info = self.agent_registry[agent_id]

        # Actualiza estado del agente a "stopping"
        agent_info.status = AgentStatus.STOPPING

        try:
            # Detiene el servicio
            success = await AgentService.stop_agent(
                port=agent_info.port, pid=agent_info.pid
            )

            # Si no puede detenerlo lanza una excepción
            if not success:
                raise AgentShutdownError(
                    agent_id=agent_id, details="No se pudo detener el servicio"
                )

            # Limpia el archivo temporal del agente
            clean_agent_service_file(agent_info.port)

            # Actualiza el estado del agente
            agent_info.status = AgentStatus.STOPPED

            # Elimina el agente del registro de la clase
            del self.agent_registry[agent_id]

            # Devuelve la información del agente eliminado
            return agent_info
        except Exception as e:
            # En caso de error, actualizar estado y relanza la excepción
            agent_info.status = AgentStatus.ERROR

            # Si no es del tipo AgentShutdownError, la envuelve
            if not isinstance(e, AgentShutdownError):
                raise AgentShutdownError(agent_id=agent_id, details=str(e))

            raise e

    async def stop_all_agents(self) -> List[AgentInfo]:
        """
        Detiene todos los agentes en ejecución

        Returns:
            List[AgentInfo]: Información de los agentes detenidos
        """

        stopped_agents = []  # Lista con los agentes a detener

        # Detiene todos los agentes existentes en el registro de la clase y
        # lo añade a la lista
        for agent_id in list(self.agent_registry.keys()):
            try:
                agent_info = await self._stop_single_agent(agent_id)
                stopped_agents.append(agent_info)
            except Exception as e:
                # Ignorar errores y continuar con el siguiente agente
                print(f"Error al detener agente {agent_id}: {str(e)}")

        return stopped_agents

    def list_agents(
        self,
        status: Optional[Union[AgentStatus, str]] = None,
        agent_name: Optional[str] = None,
    ) -> List[AgentInfo]:
        """
        Lista agentes con filtros opcionales

        Args:
            status (Optional[Union[AgentStatus, str]]): Filtrar por estado
            agent_name (Optional[str]): Filtrar por nombre

        Returns:
            List[AgentInfo]: Lista de agentes que cumplen los criterios
        """
        # Convertir status a AgentStatus si es string
        if status and isinstance(status, str):
            try:
                status = AgentStatus(status)
            except ValueError:
                # Si el estado no es válido, ignorar filtro
                status = None

        # Aplicar filtros
        filtered_agents = list(self.agent_registry.values())

        if status:
            filtered_agents = [a for a in filtered_agents if a.status == status]

        if agent_name:
            filtered_agents = [a for a in filtered_agents if a.name == agent_name]

        return filtered_agents


# Crea una instancia global de Agent Manager
agent_manager = AgentManager()
