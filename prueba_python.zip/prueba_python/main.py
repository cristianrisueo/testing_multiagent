from fastapi import FastAPI
import uvicorn
from api import router as api_router
from config import settings
from utils import ensure_directories
from services import agent_manager

# Crea la aplicación y registra las rutas
app = FastAPI(
    title=settings.APP_NAME,
    description="API para gestionar agentes de IA generativa como microservicios",
    version="1.0.0",
)

app.include_router(api_router, prefix="/api")


@app.on_event("startup")
async def startup_event():
    """
    Startup event ejecutado al iniciar el servidor
    Asegura que existen las carpetas necesarias al iniciar la aplicación
    """
    ensure_directories()


@app.on_event("shutdown")
async def shutdown_event():
    """
    Shutdown event ejecutado al detener el servidor
    Detiene todos los agentes en ejecución al cerrar la aplicación
    """
    await agent_manager.stop_all_agents()


@app.get("/")
def read_root():
    """
    Endpoint raíz que actúa como health check y devuelve información sobre la API
    """
    return {
        "app": settings.APP_NAME,
        "description": "API para gestionar agentes de IA generativa como microservicios",
        "endpoints": {
            "launch_agents": "/api/launch_agents",
            "stop_agent": "/api/stop_agent",
            "list_agents": "/api/list_agents",
        },
    }


# Arranca el servidor
if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=settings.PORT, reload=settings.DEBUG)
