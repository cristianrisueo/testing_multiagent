# Generative AI Agent Manager

Sistema de gestión para levantar agentes de inteligencia generativa como microservicios independientes.

## Descripción

Este proyecto permite lanzar, monitorizar y gestionar múltiples agentes de IA generativa como servicios web independientes. Cada agente se ejecuta en su propio puerto y puede ser controlado individualmente.

## Características

- 🚀 Levantamiento dinámico de agentes como microservicios
- 🔌 Asignación automática de puertos (8001-12001)
- 📋 Catálogo configurable de agentes disponibles
- 🔍 Monitorización de agentes en ejecución
- 🛑 Apagado controlado de servicios
- 🔄 API RESTful para gestión completa

## Requisitos

- Python 3.8+
- FastAPI
- Uvicorn
- Pydantic
- Psutil
- Requests

## Instalación

1. Clonar el repositorio:
   ```bash
   git clone https://github.com/tu-usuario/generative-ai-agent-manager.git
   cd generative-ai-agent-manager
   ```

2. Instalar dependencias:
   ```bash
   pip install -r requirements.txt
   ```

3. Instalar pydantic-settings (para Pydantic v2):
   ```bash
   pip install pydantic-settings
   ```

## Estructura del Proyecto

```
src/
├── main.py               # Punto de entrada de la aplicación
├── api.py                # Endpoints REST
├── models.py             # Modelos de datos
├── services.py           # Lógica de servicios
├── config.py             # Configuración
├── utils.py              # Utilidades
├── agents_template/      # Plantillas para servicios
│   └── main.py           # Código base de agentes
├── data/                 # Datos persistentes
│   └── agents            # Lista de agentes disponibles
└── temp/                 # Archivos temporales generados
```

### Descripción de los componentes principales

#### `main.py`
Punto de entrada de la aplicación que inicializa el servidor FastAPI principal. Configura el ciclo de vida de la aplicación, registra las rutas de la API, y gestiona los eventos de inicio y cierre. Implementa un manejador asíncrono (`lifespan`) que garantiza la correcta inicialización de recursos y la limpieza al finalizar.

#### `config.py`
Gestiona toda la configuración centralizada usando `BaseSettings` de Pydantic. Define parámetros como puertos, rutas de archivos, timeouts y nombres de aplicación. Permite la carga de configuración desde variables de entorno o un archivo `.env`, siguiendo el principio de configuración externalizada.

#### `models.py`
Define los modelos de datos y esquemas utilizando Pydantic, incluyendo:
- Excepciones personalizadas para el manejo de errores
- Payloads para peticiones API (ManifestPayload)
- Respuestas API estandarizadas
- Enumeradores para estados de agentes
- Modelos para información de agentes activos

#### `api.py`
Implementa los endpoints REST para interactuar con los agentes. Las rutas incluyen:
- Lanzamiento de agentes (`/launch_agents`)
- Listado de agentes en ejecución (`/list_agents`)
- Detención de agentes (`/stop_agent`)
Gestiona la validación de entradas, transformación de excepciones en respuestas HTTP y el enrutamiento general de la API.

#### `services.py`
Contiene la lógica de negocio principal con dos clases fundamentales:
- `AgentService`: Gestiona operaciones de bajo nivel para iniciar y detener procesos de agentes individuales
- `AgentManager`: Orquesta múltiples agentes, manteniendo registro de su estado, asignando puertos y coordinando operaciones

#### `utils.py`
Proporciona funciones auxiliares para:
- Manejo de archivos y directorios
- Lectura del catálogo de agentes disponibles
- Generación de archivos de servicio para agentes a partir de plantillas
- Limpieza de archivos temporales

## Configuración

Los agentes disponibles se definen en el archivo `data/agents`. Por defecto incluye:
```
vfs
kendra
llama
gpt4
```

Para añadir nuevos agentes, simplemente agregue sus nombres a este archivo.

## Uso

### Iniciar el Servidor

```bash
python main.py
```

El servidor principal estará disponible en http://localhost:8000

### Ejemplos de Uso con curl

Lanzar agentes:
```bash
curl -X POST http://localhost:8000/api/launch_agents \
     -H "Content-Type: application/json" \
     -d '{"agents": ["vfs", "kendra"], "resources": {}}'
```

Listar agentes en ejecución:
```bash
curl http://localhost:8000/api/list_agents
```

Detener un agente por nombre:
```bash
curl -X POST http://localhost:8000/api/stop_agent?agent_name=vfs
```

## API Reference

### Servidor Principal (Puerto 8000)

| Endpoint | Método | Descripción |
|----------|--------|-------------|
| `/api/launch_agents` | POST | Lanza uno o más agentes |
| `/api/list_agents` | GET | Lista agentes en ejecución con filtros opcionales |
| `/api/stop_agent` | POST | Detiene uno o más agentes |

### Servicios de Agente (Puertos 8001-12001)

| Endpoint | Método | Descripción |
|----------|--------|-------------|
| `/` | GET | Información básica del agente |
| `/status` | GET | Estado detallado del agente |
| `/shutdown` | GET | Inicia apagado controlado |

## Desarrollo

### Extender Funcionalidad de Agentes

Para añadir funcionalidades a los agentes, modifique la plantilla en `agents_template/main.py`. Puede añadir nuevos endpoints o lógica específica para cada tipo de agente.

### Estructura modular

El proyecto sigue un diseño modular que separa claramente:
- Configuración (`config.py`)
- Modelos de datos (`models.py`)
- Lógica de negocio (`services.py`)
- API REST (`api.py`)
- Utilidades (`utils.py`)

Esta separación permite una fácil extensión y mantenimiento.

## Casos de Uso

- **Orquestación de múltiples LLMs**: Gestione varios modelos de lenguaje con diferentes capacidades
- **Procesamiento distribuido**: Divida tareas complejas entre múltiples agentes especializados
- **Entornos de prueba**: Compare el rendimiento de diferentes agentes en tiempo real
- **Sistemas escalables**: Añada o elimine capacidades dinámicamente según la demanda

## Licencia

MIT
