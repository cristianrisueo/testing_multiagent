from fastapi import APIRouter, Query, HTTPException
from typing import Optional, List
from models import (
    ManifestPayload,
    AgentResponse,
    AgentListResponse,
    AgentLaunchResponse,
    AgentStopResponse,
    AgentStopRequest,
    AgentException,
    agent_exception_handler,
)
from services import agent_manager


router = APIRouter()  # Router del API


@router.post("/launch_agents", response_model=AgentLaunchResponse)
async def launch_agents(payload: ManifestPayload):
    """
    Lanza agentes basados en el manifest

    - Verifica si los agentes solicitados están disponibles
    - Inicia un nuevo servicio para cada agente disponible
    - Devuelve información sobre los agentes lanzados
    """
    try:
        launched_agents = await agent_manager.launch_agents(payload.agents)
        return {"launched_agents": launched_agents}
    except AgentException as exc:
        raise agent_exception_handler(exc)


@router.post("/stop_agent", response_model=AgentStopResponse)
async def stop_agent(
    request: Optional[AgentStopRequest] = None,
    agent_id: Optional[str] = Query(None),
    agent_name: Optional[str] = Query(None),
    pid: Optional[int] = Query(None),
    port: Optional[int] = Query(None),
):
    """
    Detiene agentes según los criterios proporcionados

    - Permite detener agentes usando diferentes identificadores
    - Intenta un cierre controlado
    - Devuelve información sobre los agentes detenidos
    """
    # Combinar parámetros de query y body
    if request:
        agent_id = request.agent_id or agent_id
        agent_name = request.agent_name or agent_name
        pid = request.pid or pid
        port = request.port or port

    try:
        stopped_agents = await agent_manager.stop_agent(
            agent_id=agent_id, agent_name=agent_name, pid=pid, port=port
        )
        return {"stopped_agents": stopped_agents}
    except AgentException as exc:
        raise agent_exception_handler(exc)


@router.get("/list_agents", response_model=AgentListResponse)
async def list_agents(
    status: Optional[str] = Query(
        None,
        description="Filtrar por estado (running, starting, stopping, stopped, error)",
    ),
    agent_name: Optional[str] = Query(None, description="Filtrar por nombre de agente"),
):
    """
    Lista agentes con filtros opcionales

    - Permite filtrar por estado o nombre
    - Devuelve información completa sobre los agentes
    """
    try:
        agents = agent_manager.list_agents(status=status, agent_name=agent_name)
        return {"agents": agents}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
