"""
Servicio del agente Orquestador.

Este agente coordina la comunicación entre los diferentes microservicios,
almacenando y exponiendo sus baseURLs.
"""

import uvicorn
from fastapi import FastAPI, BackgroundTasks
import os
import time
import json
import requests
from pathlib import Path
from typing import Dict

# Puerto fijo del agente
AGENT_PORT = 8004

# Crea la aplicación y registra el tiempo de inicio del servicio
app = FastAPI(title="Orchestrator Agent Service")
start_time = time.time()

# Estructura para almacenar los baseURLs de los microservicios
agents: Dict[str, str] = {}

# Definición de los agentes conocidos y sus puertos
KNOWN_AGENTS = {"vfs": 8001, "kendra": 8002, "gpt4": 8003}


def get_resources():
    """
    Busca el fichero con los resources para este microservicio
    Si lo encuentra lo devuelve en la respuesta de la petición
    """
    try:
        resources_file = Path(f"manifest_resources_{AGENT_PORT}.json")

        if resources_file.exists():
            with open(resources_file, "r") as f:
                return json.load(f)

        return {}
    except Exception as _:
        return {}


def shutdown_server():
    """
    Realiza un graceful shutdown del servidor
    Espera 1 segundo antes de cerrar para permitir que la respuesta
    HTTP sea enviada al cliente y termina el proceso
    """
    time.sleep(1)
    os._exit(0)


async def discover_agents():
    """
    Descubre los agentes disponibles y almacena sus baseURLs
    """
    # Limpia la estructura existente
    agents.clear()

    # Busca todos los agentes conocidos
    for agent_name, port in KNOWN_AGENTS.items():
        try:
            # Intenta conectar al endpoint de status del microservicio
            response = requests.get(f"http://localhost:{port}/status", timeout=1)

            # Si responde, almacena su baseURL
            if response.status_code == 200:
                agents[agent_name] = f"http://localhost:{port}"
                print(
                    f"Descubierto microservicio: {agent_name} en {agents[agent_name]}"
                )
        except Exception as e:
            # Si no responde, ignora este microservicio
            print(f"No se pudo conectar con el microservicio {agent_name}: {str(e)}")


@app.on_event("startup")
async def startup_event():
    """
    Evento que se ejecuta al iniciar el servicio
    Descubre los agentes disponibles
    """
    await discover_agents()


@app.get("/")
def read_root():
    """
    Endpoint raíz que identifica el servicio
    """
    return {"message": f"Soy el agente orquestador iniciado en el puerto {AGENT_PORT}"}


@app.get("/status")
def status():
    """Proporciona información sobre el estado del servicio."""
    uptime = time.time() - start_time

    return {
        "status": "running",
        "agent": "orchestrator",
        "port": AGENT_PORT,
        "pid": os.getpid(),
        "uptime_seconds": uptime,
    }


@app.get("/shutdown")
def shutdown(background_tasks: BackgroundTasks):
    """Inicia el proceso de apagado controlado del servicio."""
    background_tasks.add_task(shutdown_server)
    return {"message": "Servicio cerrándose..."}


@app.get("/discover")
async def discover():
    """
    Endpoint para forzar el descubrimiento de agentes
    """
    await discover_agents()
    return {
        "message": "Descubrimiento de agentes completado",
        "count": len(agents),
    }


@app.get("/agents")
def get_agents():
    """
    Endpoint que devuelve la lista de agentes disponibles
    """
    return {"agents": agents}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=AGENT_PORT)
