"""
Tests para el módulo services.py.

Este archivo contiene pruebas unitarias para verificar:
- La funcionalidad del AgentManager
- El lanzamiento y detención de agentes
- El manejo de puertos y recursos
- El manejo de errores y excepciones
"""

import pytest
import time
import signal
import os
from unittest.mock import patch, MagicMock, mock_open, AsyncMock
import requests
from src.services import AgentManager, AgentService
from src.models import (
    AgentInfo,
    AgentStatus,
    AgentStartupError,
    AgentNotAvailableError,
    AgentAlreadyRunningError,
    AgentNotFoundError,
    AgentShutdownError,
)
from src.config import settings
from pathlib import Path


@pytest.fixture
def agent_manager():
    """Fixture que proporciona una instancia de AgentManager."""
    return AgentManager()


@pytest.fixture
def mock_agent_info():
    """Fixture que proporciona información de un agente para pruebas."""
    return AgentInfo(
        id="test-agent-id",
        name="vfs",
        pid=12345,
        port=8001,
        status=AgentStatus.RUNNING,
        start_time=time.time(),
    )


@pytest.mark.asyncio
async def test_agent_manager_initialization(agent_manager):
    """
    Test para verificar la inicialización correcta del AgentManager.

    Verifica que las estructuras de datos internas se inicializan correctamente.
    """
    assert agent_manager.agent_registry == {}
    assert agent_manager.last_assigned_port == settings.MIN_AGENT_PORT - 1
    assert agent_manager.available_ports == []
    assert agent_manager.active_agents_by_name == {}


@pytest.mark.asyncio
async def test_get_next_available_port(agent_manager):
    """
    Test para verificar la asignación correcta de puertos.

    Comprueba que los puertos se asignan secuencialmente y se reutilizan
    correctamente cuando están disponibles.
    """
    # Primera asignación: debe ser MIN_AGENT_PORT
    port1 = agent_manager.get_next_available_port()
    assert port1 == settings.MIN_AGENT_PORT

    # Segunda asignación: debe ser MIN_AGENT_PORT + 1
    port2 = agent_manager.get_next_available_port()
    assert port2 == settings.MIN_AGENT_PORT + 1

    # Añade un puerto a la lista de disponibles (simula un puerto liberado)
    agent_manager.available_ports.append(8010)

    # Tercera asignación: debe usar el puerto reutilizado
    port3 = agent_manager.get_next_available_port()
    assert port3 == 8010  # Puerto reutilizado
    assert agent_manager.available_ports == []  # Lista vacía después de usar el puerto

    # Verifica que se reinicia el contador si se alcanza el límite máximo
    agent_manager.last_assigned_port = settings.MAX_AGENT_PORT
    port4 = agent_manager.get_next_available_port()
    assert port4 == settings.MIN_AGENT_PORT


@pytest.mark.asyncio
@patch("pathlib.Path.exists")
async def test_launch_agents_directory_not_exists(mock_exists, agent_manager):
    """
    Test para verificar el manejo de errores cuando el directorio de agentes no existe.

    Comprueba que se lanza una excepción apropiada cuando el directorio
    de agentes no existe.
    """
    mock_exists.return_value = False

    with pytest.raises(IOError):
        await agent_manager.launch_agents(["vfs"], {})

    mock_exists.assert_called_once()


@pytest.mark.asyncio
async def test_launch_agents_already_running(agent_manager, mock_agent_info):
    """
    Test para verificar que no se puede lanzar un agente que ya está en ejecución.

    Comprueba que se lanza una excepción apropiada cuando se intenta lanzar
    un agente que ya está en ejecución.
    """
    # Registra un agente como activo
    agent_manager.active_agents_by_name["vfs"] = mock_agent_info.id

    # Intenta lanzar el mismo agente
    with pytest.raises(AgentAlreadyRunningError):
        await agent_manager.launch_agents(["vfs"], {})


@pytest.mark.asyncio
@patch("pathlib.Path.exists")
@patch("src.services.AgentService.start_agent")
async def test_launch_agents_success(mock_start_agent, mock_exists, agent_manager):
    """
    Test para verificar el lanzamiento exitoso de agentes.

    Comprueba que los agentes se lanzan correctamente y se registran
    en las estructuras internas del AgentManager.
    """
    # Configura los mocks
    mock_exists.return_value = True
    mock_start_agent.return_value = 12345

    # Lanza un agente
    agents = await agent_manager.launch_agents(["vfs"], {"test-key": "test-value"})

    # Verifica que se devolvió la información correcta
    assert len(agents) == 1
    assert agents[0].name == "vfs"
    assert agents[0].pid == 12345
    assert agents[0].status == AgentStatus.RUNNING

    # Verifica que se registró correctamente
    assert "vfs" in agent_manager.active_agents_by_name
    assert len(agent_manager.agent_registry) == 1


@pytest.mark.asyncio
@patch("pathlib.Path.exists")
@patch("src.services.AgentService.start_agent")
async def test_launch_multiple_agents(mock_start_agent, mock_exists, agent_manager):
    """
    Test para verificar el lanzamiento exitoso de múltiples agentes.

    Comprueba que se pueden lanzar múltiples agentes correctamente
    y que se registran en las estructuras internas del AgentManager.
    """
    # Configura los mocks
    mock_exists.return_value = True
    mock_start_agent.side_effect = [12345, 12346, 12347]

    # Lanza múltiples agentes
    agents = await agent_manager.launch_agents(
        ["vfs", "kendra", "gpt4"], {"global": "resource"}
    )

    # Verifica que se devolvieron los tres agentes
    assert len(agents) == 3
    agent_names = [a.name for a in agents]
    assert "vfs" in agent_names
    assert "kendra" in agent_names
    assert "gpt4" in agent_names

    # Verifica que se registraron correctamente
    assert len(agent_manager.active_agents_by_name) == 3
    assert "vfs" in agent_manager.active_agents_by_name
    assert "kendra" in agent_manager.active_agents_by_name
    assert "gpt4" in agent_manager.active_agents_by_name
    assert len(agent_manager.agent_registry) == 3


@pytest.mark.asyncio
@patch("pathlib.Path.exists")
@patch("src.services.AgentService.start_agent")
async def test_launch_agent_single(mock_start_agent, mock_exists, agent_manager):
    """
    Test para verificar el lanzamiento exitoso de un solo agente.

    Comprueba que un agente individual se lanza correctamente usando
    el método launch_agent y se registra adecuadamente.
    """
    # Configura los mocks
    mock_exists.return_value = True
    mock_start_agent.return_value = 12345

    # Lanza un agente
    agent_info = await agent_manager.launch_agent("vfs", {"test-key": "test-value"})

    # Verifica que se devolvió la información correcta
    assert agent_info.name == "vfs"
    assert agent_info.pid == 12345
    assert agent_info.status == AgentStatus.RUNNING
    assert agent_info.port == 8001  # Puerto fijo para vfs

    # Verifica que se registró correctamente
    assert "vfs" in agent_manager.active_agents_by_name
    assert agent_manager.active_agents_by_name["vfs"] == agent_info.id
    assert agent_info.id in agent_manager.agent_registry


@pytest.mark.asyncio
@patch("src.services.AgentService.start_agent", side_effect=Exception("Test error"))
async def test_launch_agent_error(mock_start_agent, agent_manager):
    """
    Test para verificar el manejo de errores al lanzar un agente.

    Comprueba que se manejan correctamente los errores durante el lanzamiento
    de un agente y se actualiza su estado a ERROR.
    """
    # Intenta lanzar un agente que fallará
    with pytest.raises(Exception):
        await agent_manager.launch_agent("vfs")

    # Verifica que no se registró como activo
    assert "vfs" not in agent_manager.active_agents_by_name

    # Verifica que no está en el registro o tiene estado ERROR
    for agent_id, agent_info in agent_manager.agent_registry.items():
        if agent_info.name == "vfs":
            assert agent_info.status == AgentStatus.ERROR


@pytest.mark.asyncio
async def test_stop_agent_no_criteria(agent_manager):
    """
    Test para verificar que no se puede detener un agente sin proporcionar criterios.

    Comprueba que se lanza una excepción apropiada cuando se intenta
    detener un agente sin proporcionar ningún criterio.
    """
    # Intenta detener un agente sin criterios
    with pytest.raises(ValueError):
        await agent_manager.stop_agent()


@pytest.mark.asyncio
async def test_stop_agent_not_found(agent_manager):
    """
    Test para verificar que no se puede detener un agente que no existe.

    Comprueba que se lanza una excepción apropiada cuando se intenta
    detener un agente que no existe.
    """
    # Intenta detener un agente que no existe
    with pytest.raises(AgentNotFoundError):
        await agent_manager.stop_agent(agent_id="nonexistent-id")


@pytest.mark.asyncio
@patch("src.services.AgentService.stop_agent")
async def test_stop_agent_by_id_success(
    mock_stop_agent, agent_manager, mock_agent_info
):
    """
    Test para verificar la detención exitosa de un agente por ID.

    Comprueba que un agente se detiene correctamente cuando se proporciona
    su ID y se actualiza su estado y registros.
    """
    # Configura el mock
    mock_stop_agent.return_value = True

    # Registra un agente
    agent_manager.agent_registry[mock_agent_info.id] = mock_agent_info
    agent_manager.active_agents_by_name[mock_agent_info.name] = mock_agent_info.id

    # Detiene el agente por ID
    stopped_agents = await agent_manager.stop_agent(agent_id=mock_agent_info.id)

    # Verifica que se devolvió la información correcta
    assert len(stopped_agents) == 1
    assert stopped_agents[0].id == mock_agent_info.id
    assert stopped_agents[0].name == mock_agent_info.name

    # Verifica que se eliminó de los registros
    assert mock_agent_info.name not in agent_manager.active_agents_by_name
    assert mock_agent_info.id not in agent_manager.agent_registry

    # Verifica que el puerto se añadió a los disponibles
    assert mock_agent_info.port in agent_manager.available_ports


@pytest.mark.asyncio
@patch("src.services.AgentService.stop_agent")
async def test_stop_agent_by_name_success(
    mock_stop_agent, agent_manager, mock_agent_info
):
    """
    Test para verificar la detención exitosa de un agente por nombre.

    Comprueba que un agente se detiene correctamente cuando se proporciona
    su nombre y se actualiza su estado y registros.
    """
    # Configura el mock
    mock_stop_agent.return_value = True

    # Registra un agente
    agent_manager.agent_registry[mock_agent_info.id] = mock_agent_info
    agent_manager.active_agents_by_name[mock_agent_info.name] = mock_agent_info.id

    # Detiene el agente por nombre
    stopped_agents = await agent_manager.stop_agent(agent_name=mock_agent_info.name)

    # Verifica que se devolvió la información correcta
    assert len(stopped_agents) == 1
    assert stopped_agents[0].id == mock_agent_info.id
    assert stopped_agents[0].name == mock_agent_info.name

    # Verifica que se eliminó de los registros
    assert mock_agent_info.name not in agent_manager.active_agents_by_name
    assert mock_agent_info.id not in agent_manager.agent_registry


@pytest.mark.asyncio
@patch("src.services.AgentService.stop_agent")
async def test_stop_all_agents(mock_stop_agent, agent_manager):
    """
    Test para verificar la detención de todos los agentes.

    Comprueba que todos los agentes se detienen correctamente cuando
    se llama al método stop_all_agents y se actualizan los registros.
    """
    # Configura el mock
    mock_stop_agent.return_value = True

    # Registra varios agentes
    agents = []
    for i, name in enumerate(["vfs", "kendra", "gpt4"]):
        agent = AgentInfo(
            id=f"test-agent-id-{i}",
            name=name,
            pid=12345 + i,
            port=8001 + i,
            status=AgentStatus.RUNNING,
            start_time=time.time(),
        )
        agent_manager.agent_registry[agent.id] = agent
        agent_manager.active_agents_by_name[agent.name] = agent.id
        agents.append(agent)

    # Detiene todos los agentes
    stopped_agents = await agent_manager.stop_all_agents()

    # Verifica que se devolvieron todos los agentes
    assert len(stopped_agents) == 3

    # Verifica que se eliminaron de los registros
    assert len(agent_manager.active_agents_by_name) == 0
    assert len(agent_manager.agent_registry) == 0

    # Verifica que los puertos se añadieron a los disponibles
    assert len(agent_manager.available_ports) == 3


@pytest.mark.asyncio
@patch("src.services.AgentService.stop_agent", side_effect=Exception("Test error"))
async def test_stop_all_agents_with_errors(mock_stop_agent, agent_manager):
    """
    Test para verificar la detención de todos los agentes cuando hay errores.

    Comprueba que el método stop_all_agents maneja correctamente los errores
    y continúa intentando detener todos los agentes.
    """
    # Registra varios agentes
    for i, name in enumerate(["vfs", "kendra", "gpt4"]):
        agent = AgentInfo(
            id=f"test-agent-id-{i}",
            name=name,
            pid=12345 + i,
            port=8001 + i,
            status=AgentStatus.RUNNING,
            start_time=time.time(),
        )
        agent_manager.agent_registry[agent.id] = agent
        agent_manager.active_agents_by_name[agent.name] = agent.id

    # Detiene todos los agentes (debería manejar los errores)
    stopped_agents = await agent_manager.stop_all_agents()

    # Verifica que no se devolvió ningún agente detenido
    assert len(stopped_agents) == 0

    # Verifica que se intentó detener todos los agentes
    assert mock_stop_agent.call_count == 3


@pytest.mark.asyncio
@patch("src.services.requests.get")
@patch("src.services.subprocess.Popen")
@patch("pathlib.Path.exists")
@patch("src.services.generate_agent_command")
@patch("src.services.save_agent_resources")
async def test_agent_service_start_success(
    mock_save_resources,
    mock_generate_command,
    mock_exists,
    mock_popen,
    mock_requests_get,
):
    """
    Test para verificar el inicio exitoso de un servicio de agente.

    Comprueba que un servicio de agente se inicia correctamente, responde
    a las solicitudes de estado y devuelve el PID apropiado.
    """
    # Configura los mocks
    mock_save_resources.return_value = "/tmp/resources.json"
    mock_generate_command.return_value = ["echo", "test"]
    mock_exists.return_value = True

    mock_process = MagicMock()
    mock_process.pid = 12345
    mock_process.communicate.return_value = (b"", b"")
    mock_popen.return_value = mock_process

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.text = '{"status": "ok"}'
    mock_requests_get.return_value = mock_response

    # Inicia un servicio
    pid = await AgentService.start_agent(
        "vfs", 8001, {"test-key": "test-value"}, "test-id"
    )

    # Verifica que se devolvió el PID correcto
    assert pid == 12345

    # Verifica que se llamaron los métodos esperados
    mock_save_resources.assert_called_once()
    mock_generate_command.assert_called_once()
    mock_popen.assert_called_once()
    mock_requests_get.assert_called_once()


@pytest.mark.asyncio
@patch("src.services.requests.get")
@patch("src.services.psutil.pid_exists")
@patch("src.services.clean_agent_resources")
async def test_agent_service_stop_graceful(
    mock_clean_resources, mock_pid_exists, mock_requests_get
):
    """
    Test para verificar la detención graceful de un servicio.

    Comprueba que un servicio se detiene correctamente mediante
    una solicitud HTTP al endpoint /shutdown.
    """
    # Configura los mocks
    mock_clean_resources.return_value = True

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_requests_get.return_value = mock_response

    # Configura pid_exists para indicar que el proceso terminó
    mock_pid_exists.return_value = False

    # Detiene un servicio
    result = await AgentService.stop_agent("vfs", 8001, 12345)

    # Verifica que la detención fue exitosa
    assert result is True

    # Verifica que se llamó al endpoint /shutdown
    mock_requests_get.assert_called_once_with(
        "http://localhost:8001/shutdown", timeout=2
    )

    # Verifica que se verificó si el PID existe
    mock_pid_exists.assert_called_once()

    # Verifica que se limpiaron los recursos
    mock_clean_resources.assert_called_once()


@pytest.mark.asyncio
@patch("src.services.requests.get")
@patch("src.services.psutil.pid_exists")
@patch("src.services.os.kill")
@patch("src.services.clean_agent_resources")
async def test_agent_service_stop_forced_termination(
    mock_clean_resources, mock_kill, mock_pid_exists, mock_requests_get
):
    """
    Test para verificar la terminación forzosa de un servicio.

    Comprueba que un servicio se termina forzosamente si el
    proceso no responde al graceful shutdown.
    """
    # Configura los mocks
    mock_clean_resources.return_value = True

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_requests_get.return_value = mock_response

    # Configura pid_exists para indicar que el proceso sigue vivo
    mock_pid_exists.return_value = True

    # Configura un timeout más corto para la prueba
    original_timeout = settings.AGENT_SHUTDOWN_TIMEOUT
    settings.AGENT_SHUTDOWN_TIMEOUT = 0.1

    # Detiene un servicio
    result = await AgentService.stop_agent("vfs", 8001, 12345)

    # Restaura el timeout original
    settings.AGENT_SHUTDOWN_TIMEOUT = original_timeout

    # Verifica que la detención fue exitosa
    assert result is True

    # Verifica que se llamó a os.kill
    mock_kill.assert_called()

    # Verifica que se limpiaron los recursos
    mock_clean_resources.assert_called_once()


@pytest.mark.asyncio
@patch("src.services.requests.get")
@patch("src.services.psutil.pid_exists")
@patch("src.services.os.kill")
@patch("src.services.clean_agent_resources")
async def test_agent_service_stop_http_error(
    mock_clean_resources, mock_kill, mock_pid_exists, mock_requests_get
):
    """
    Test para verificar el manejo de errores HTTP al detener un servicio.

    Comprueba que un servicio se termina correctamente incluso si
    la solicitud HTTP al endpoint /shutdown falla.
    """
    # Configura los mocks
    mock_clean_resources.return_value = True

    # Configura requests.get para lanzar una excepción
    mock_requests_get.side_effect = requests.RequestException("Connection error")

    # Configura pid_exists para indicar que el proceso terminó después del kill
    mock_pid_exists.return_value = False

    # Detiene un servicio
    result = await AgentService.stop_agent("vfs", 8001, 12345)

    # Verifica que la detención fue exitosa
    assert result is True

    # Verifica que se llamó a os.kill
    mock_kill.assert_called_once()

    # Verifica que se limpiaron los recursos
    mock_clean_resources.assert_called_once()


@pytest.mark.asyncio
@patch("src.services.agent_manager")
def test_fixed_ports_for_predefined_agents(mock_agent_manager):
    """
    Test para verificar que los agentes predefinidos usan puertos fijos.

    Comprueba que los agentes vfs, kendra y gpt4 tienen asignados
    los puertos fijos 8001, 8002 y 8003 respectivamente.
    """
    from src.utils import get_agent_fixed_port

    # Verifica los puertos fijos para los agentes predefinidos
    assert get_agent_fixed_port("vfs") == 8001
    assert get_agent_fixed_port("kendra") == 8002
    assert get_agent_fixed_port("gpt4") == 8003

    # Verifica que otros agentes no tienen puertos fijos
    assert get_agent_fixed_port("other-agent") == 0


@pytest.mark.asyncio
@patch("builtins.open", new_callable=mock_open)
@patch("json.dump")
@patch("src.utils.Path.exists")
@patch("src.utils.Path.mkdir")
def test_save_agent_resources_ports(mock_mkdir, mock_exists, mock_json_dump, mock_open):
    """
    Test para verificar que save_agent_resources usa los puertos correctos.

    Comprueba que la función save_agent_resources utiliza los puertos
    fijos para los agentes predefinidos.
    """
    from src.utils import save_agent_resources

    # Configura los mocks
    mock_exists.return_value = True
    mock_mkdir.return_value = None

    # Prueba con agente predefinido (vfs)
    _ = save_agent_resources("vfs", 9999, {"test": "value"}, "test-id")

    # Verifica que se abrió con el puerto fijo (8001)
    mock_open.assert_called_with(
        Path(f"{settings.AGENTS_DIR}/vfs/manifest_resources_8001.json"), "w"
    )

    # Reinicia los mocks
    mock_open.reset_mock()

    # Prueba con agente no predefinido
    _ = save_agent_resources("other-agent", 9999, {"test": "value"}, "test-id")

    # Verifica que se abrió con el puerto proporcionado (9999)
    mock_open.assert_called_with(
        Path(f"{settings.AGENTS_DIR}/other-agent/manifest_resources_9999.json"), "w"
    )


@pytest.mark.asyncio
@patch("src.utils.Path.exists", return_value=False)
def test_generate_agent_command_file_not_found(mock_exists):
    """
    Test para verificar que generate_agent_command maneja errores de archivo.

    Comprueba que la función generate_agent_command lanza la excepción
    apropiada cuando el archivo asgi.py no existe.
    """
    from src.utils import generate_agent_command

    # Intenta generar un comando para un agente cuyo archivo asgi.py no existe
    with pytest.raises(IOError):
        generate_agent_command("vfs", 8001)


@pytest.mark.asyncio
def test_agent_manager_list_agents(agent_manager, mock_agent_info):
    """
    Test para verificar que list_agents filtra correctamente los agentes.

    Comprueba que el método list_agents devuelve correctamente los agentes
    que coinciden con los filtros proporcionados.
    """
    # Registra varios agentes
    agent1 = mock_agent_info

    agent2 = AgentInfo(
        id="test-agent-id-2",
        name="kendra",
        pid=12346,
        port=8002,
        status=AgentStatus.ERROR,
        start_time=time.time(),
    )

    agent3 = AgentInfo(
        id="test-agent-id-3",
        name="gpt4",
        pid=12347,
        port=8003,
        status=AgentStatus.RUNNING,
        start_time=time.time(),
    )

    agent_manager.agent_registry[agent1.id] = agent1
    agent_manager.agent_registry[agent2.id] = agent2
    agent_manager.agent_registry[agent3.id] = agent3

    # Lista sin filtros
    agents = agent_manager.list_agents()
    assert len(agents) == 3

    # Lista filtrada por estado
    agents = agent_manager.list_agents(status=AgentStatus.RUNNING)
    assert len(agents) == 2
    assert all(a.status == AgentStatus.RUNNING for a in agents)

    # Lista filtrada por nombre
    agents = agent_manager.list_agents(agent_name="vfs")
    assert len(agents) == 1
    assert agents[0].name == "vfs"

    # Lista filtrada por estado y nombre
    agents = agent_manager.list_agents(status=AgentStatus.RUNNING, agent_name="vfs")
    assert len(agents) == 1
    assert agents[0].name == "vfs"
    assert agents[0].status == AgentStatus.RUNNING

    # Lista con filtros que no coinciden
    agents = agent_manager.list_agents(status=AgentStatus.STOPPING)
    assert len(agents) == 0


@pytest.mark.asyncio
def test_agent_manager_list_agents_string_status(agent_manager, mock_agent_info):
    """
    Test para verificar que list_agents maneja correctamente estados en formato string.

    Comprueba que el método list_agents convierte correctamente los estados
    de string a AgentStatus y filtra apropiadamente.
    """
    # Registra agentes con diferentes estados
    agent1 = mock_agent_info  # RUNNING

    agent2 = AgentInfo(
        id="test-agent-id-2",
        name="kendra",
        pid=12346,
        port=8002,
        status=AgentStatus.ERROR,
        start_time=time.time(),
    )

    agent_manager.agent_registry[agent1.id] = agent1
    agent_manager.agent_registry[agent2.id] = agent2

    # Lista filtrada por estado en formato string
    agents = agent_manager.list_agents(status="running")
    assert len(agents) == 1
    assert agents[0].status == AgentStatus.RUNNING

    # Lista con estado string inválido (debería ignorar el filtro)
    agents = agent_manager.list_agents(status="invalid_status")
    assert len(agents) == 2  # Devuelve todos los agentes


@pytest.mark.asyncio
@patch("src.utils.Path.exists")
@patch("src.utils.Path.unlink")
def test_ensure_directories(mock_unlink, mock_exists):
    """
    Test para verificar que ensure_directories crea los directorios necesarios.

    Comprueba que la función ensure_directories crea los directorios
    necesarios para la aplicación.
    """
    from src.utils import ensure_directories

    # Configura el mock
    mock_exists.return_value = False

    # Parcha mkdir para que no intente crear directorios reales
    with patch("src.utils.Path.mkdir") as mock_mkdir:
        # Llama a la función
        ensure_directories()

        # Verifica que se intentó crear el directorio de logs
        mock_mkdir.assert_called()


@pytest.mark.asyncio
def test_agent_status_enum():
    """
    Test para verificar que AgentStatus contiene los estados necesarios.

    Comprueba que el enum AgentStatus define todos los estados necesarios
    para los agentes y que se pueden usar para comparaciones.
    """
    # Verifica todos los estados del enum
    assert AgentStatus.RUNNING.value == "running"
    assert AgentStatus.STARTING.value == "starting"
    assert AgentStatus.STOPPING.value == "stopping"
    assert AgentStatus.STOPPED.value == "stopped"
    assert AgentStatus.ERROR.value == "error"

    # Verifica la representación como string
    assert AgentStatus.RUNNING.value == "running"


@pytest.mark.asyncio
@patch("src.services.AgentService.start_agent")
@patch("pathlib.Path.exists")
async def test_launch_agents_with_global_resources(
    mock_exists, mock_start_agent, agent_manager
):
    """
    Test para verificar que los recursos globales se pasan a todos los agentes.

    Comprueba que los recursos comunes se pasan a todos los agentes
    cuando se lanzan múltiples agentes.
    """
    # Configura los mocks
    mock_exists.return_value = True
    mock_start_agent.return_value = 12345

    # Define recursos globales
    resources = {
        "sharepoint": {
            "url": "https://example.com",
            "user": "test_user",
            "password": "test_password",
        },
        "timeout": 30,
    }

    # Lanza múltiples agentes
    await agent_manager.launch_agents(["vfs", "kendra"], resources)

    # Verifica que se llamó a start_agent para cada agente con los recursos globales
    assert mock_start_agent.call_count == 2

    # Extrae los recursos pasados a cada agente
    calls = mock_start_agent.call_args_list

    # Verifica los recursos para el primer agente
    first_call_args = calls[0][0]
    first_agent_name = first_call_args[0]
    first_agent_resources = first_call_args[2]

    # Verifica los recursos para el segundo agente
    second_call_args = calls[1][0]
    second_agent_name = second_call_args[0]
    second_agent_resources = second_call_args[2]

    # Verifica que ambos agentes recibieron los recursos globales
    assert "sharepoint" in first_agent_resources
    assert "timeout" in first_agent_resources
    assert "sharepoint" in second_agent_resources
    assert "timeout" in second_agent_resources


@pytest.mark.asyncio
@patch("src.services.AgentService.start_agent")
@patch("pathlib.Path.exists")
async def test_launch_agent_kendra(mock_exists, mock_start_agent, agent_manager):
    """
    Test para verificar el lanzamiento del agente kendra.

    Comprueba que el agente kendra se lanza correctamente con su puerto fijo.
    """
    # Configura los mocks
    mock_exists.return_value = True
    mock_start_agent.return_value = 12345

    # Lanza el agente kendra
    agent_info = await agent_manager.launch_agent("kendra")

    # Verifica que se devolvió la información correcta
    assert agent_info.name == "kendra"
    assert agent_info.pid == 12345
    assert agent_info.status == AgentStatus.RUNNING
    assert agent_info.port == 8002  # Puerto fijo para kendra

    # Verifica que se registró correctamente
    assert "kendra" in agent_manager.active_agents_by_name
    assert agent_manager.active_agents_by_name["kendra"] == agent_info.id
    assert agent_info.id in agent_manager.agent_registry


@pytest.mark.asyncio
@patch("src.services.AgentService.start_agent")
@patch("pathlib.Path.exists")
async def test_launch_agent_gpt4(mock_exists, mock_start_agent, agent_manager):
    """
    Test para verificar el lanzamiento del agente gpt4.

    Comprueba que el agente gpt4 se lanza correctamente con su puerto fijo.
    """
    # Configura los mocks
    mock_exists.return_value = True
    mock_start_agent.return_value = 12345

    # Lanza el agente gpt4
    agent_info = await agent_manager.launch_agent("gpt4")

    # Verifica que se devolvió la información correcta
    assert agent_info.name == "gpt4"
    assert agent_info.pid == 12345
    assert agent_info.status == AgentStatus.RUNNING
    assert agent_info.port == 8003  # Puerto fijo para gpt4

    # Verifica que se registró correctamente
    assert "gpt4" in agent_manager.active_agents_by_name
    assert agent_manager.active_agents_by_name["gpt4"] == agent_info.id
    assert agent_info.id in agent_manager.agent_registry


@pytest.mark.asyncio
@patch("src.services.AgentService.stop_agent")
async def test_stop_agent_by_pid_success(mock_stop_agent, agent_manager):
    """
    Test para verificar la detención exitosa de un agente por PID.

    Comprueba que un agente se detiene correctamente cuando se proporciona
    su PID y se actualiza su estado y registros.
    """
    # Configura el mock
    mock_stop_agent.return_value = True

    # Crea un agente
    agent = AgentInfo(
        id="test-agent-id",
        name="vfs",
        pid=12345,
        port=8001,
        status=AgentStatus.RUNNING,
        start_time=time.time(),
    )

    # Registra el agente
    agent_manager.agent_registry[agent.id] = agent
    agent_manager.active_agents_by_name[agent.name] = agent.id

    # Detiene el agente por PID
    stopped_agents = await agent_manager.stop_agent(pid=12345)

    # Verifica que se devolvió la información correcta
    assert len(stopped_agents) == 1
    assert stopped_agents[0].id == agent.id
    assert stopped_agents[0].name == agent.name
    assert stopped_agents[0].pid == 12345

    # Verifica que se eliminó de los registros
    assert agent.name not in agent_manager.active_agents_by_name
    assert agent.id not in agent_manager.agent_registry


@pytest.mark.asyncio
@patch("src.services.AgentService.stop_agent")
async def test_stop_agent_by_port_success(mock_stop_agent, agent_manager):
    """
    Test para verificar la detención exitosa de un agente por puerto.

    Comprueba que un agente se detiene correctamente cuando se proporciona
    su puerto y se actualiza su estado y registros.
    """
    # Configura el mock
    mock_stop_agent.return_value = True

    # Crea un agente
    agent = AgentInfo(
        id="test-agent-id",
        name="kendra",
        pid=12345,
        port=8002,
        status=AgentStatus.RUNNING,
        start_time=time.time(),
    )

    # Registra el agente
    agent_manager.agent_registry[agent.id] = agent
    agent_manager.active_agents_by_name[agent.name] = agent.id

    # Detiene el agente por puerto
    stopped_agents = await agent_manager.stop_agent(port=8002)

    # Verifica que se devolvió la información correcta
    assert len(stopped_agents) == 1
    assert stopped_agents[0].id == agent.id
    assert stopped_agents[0].name == agent.name
    assert stopped_agents[0].port == 8002

    # Verifica que se eliminó de los registros
    assert agent.name not in agent_manager.active_agents_by_name
    assert agent.id not in agent_manager.agent_registry
