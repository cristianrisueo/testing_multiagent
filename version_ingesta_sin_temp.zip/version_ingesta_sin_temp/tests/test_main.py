"""
Tests para el fichero main de la aplicación.

Este archivo contiene pruebas unitarias para verificar:
- El funcionamiento del endpoint raíz
- El ciclo de vida de la aplicación (inicio y cierre)
- La configuración básica de la aplicación
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch
from src.main import app
from src.config import settings


# Cliente de prueba para la API
client = TestClient(app)


def test_lifespan_startup(monkeypatch):
    """
    Test para verificar las funciones de inicio del ciclo de vida.

    Comprueba que durante el inicio de la aplicación se llamen
    correctamente a las funciones necesarias como ensure_directories.
    """

    # Mock para la función ensure_directories
    called = False

    def mock_ensure_directories():
        nonlocal called
        called = True

    # Reemplaza la función original por la mockeada
    monkeypatch.setattr("src.main.ensure_directories", mock_ensure_directories)

    # Crea un cliente de prueba (esto ejecuta el lifespan startup)
    with TestClient(app) as test_client:
        pass

    # Verifica que se llamó a ensure_directories (se llama en el startup)
    assert called, "La función ensure_directories no fue llamada durante el startup"


@pytest.mark.asyncio
async def test_lifespan_shutdown(monkeypatch):
    """
    Test para verificar las funciones de cierre del ciclo de vida.

    Comprueba que durante el cierre de la aplicación se llamen
    correctamente a las funciones para detener todos los agentes.
    """

    # Mock para el método stop_all_agents
    called = False

    async def mock_stop_all_agents():
        nonlocal called
        called = True
        return []

    # Reemplaza la función original por la mockeada
    monkeypatch.setattr("src.main.agent_manager.stop_all_agents", mock_stop_all_agents)

    # Simula el contexto del lifespan
    async def mock_lifespan_context():
        async with app.router.lifespan_context(app):
            pass

    # Ejecuta el contexto simulado
    await mock_lifespan_context()

    # Verifica que se llamó a stop_all_agents
    assert called, "El método stop_all_agents no fue llamado durante el shutdown"


def test_swagger_docs():
    """
    Test para verificar que la documentación Swagger está disponible.

    Comprueba que la documentación de la API está correctamente configurada
    y accesible en la ruta "/docs".
    """
    response = client.get("/docs")

    # Verifica que la respuesta es código 200 (OK)
    assert response.status_code == 200

    # Verifica que la respuesta contiene "swagger" en el contenido
    assert "swagger" in response.text.lower()


def test_redoc_docs():
    """
    Test para verificar que la documentación ReDoc está disponible.

    Comprueba que la documentación alternativa de la API está correctamente
    configurada y accesible en la ruta "/redoc".
    """
    response = client.get("/redoc")

    # Verifica que la respuesta es código 200 (OK)
    assert response.status_code == 200

    # Verifica que la respuesta contiene "redoc" en el contenido
    assert "redoc" in response.text.lower()


def test_openapi_json():
    """
    Test para verificar que el esquema OpenAPI está disponible.

    Comprueba que el esquema OpenAPI de la API está correctamente configurado
    y accesible en la ruta "/openapi.json".
    """
    response = client.get("/openapi.json")

    # Verifica que la respuesta es código 200 (OK)
    assert response.status_code == 200

    # Verifica que la respuesta contiene los elementos OpenAPI básicos
    data = response.json()
    assert "openapi" in data
    assert "paths" in data
    assert "components" in data
    assert "info" in data
    assert data["info"]["title"] == settings.APP_NAME
    assert data["info"]["version"] == settings.VERSION


@patch("src.main.logger")
def test_app_startup_logging(mock_logger):
    """
    Test para verificar que se registran logs apropiados durante el inicio.

    Comprueba que se registran los mensajes de log esperados cuando
    se inicia la aplicación.
    """
    # Crea un cliente de prueba (esto ejecuta el lifespan startup)
    with TestClient(app) as test_client:
        pass

    # Verifica que se llamó a logger.info con el mensaje de inicio
    expected_msg = (
        f"{settings.APP_NAME} v{settings.VERSION} iniciado en el puerto {settings.PORT}"
    )
    mock_logger.info.assert_any_call(expected_msg)


@patch("src.main.logger")
def test_app_shutdown_logging(mock_logger):
    """
    Test para verificar que se registran logs apropiados durante el cierre.

    Comprueba que se registran los mensajes de log esperados cuando
    se cierra la aplicación.
    """
    # Crea un cliente de prueba (esto ejecuta el lifespan startup y shutdown)
    with TestClient(app) as test_client:
        pass

    # Verifica que se llamó a logger.info con los mensajes de cierre
    mock_logger.info.assert_any_call("Deteniendo todos los agentes activos...")
    mock_logger.info.assert_any_call("Aplicación cerrada correctamente")
