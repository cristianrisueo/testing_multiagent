import sys
import json
from typing import List, Dict, Any
from .config import settings, app_logger as logger


def ensure_directories() -> None:
    """
    Asegura que existen las carpetas básicas necesarias para la aplicación.

    Crea:
    - El directorio de logs
    """
    # Crea los directorios básicos necesarios
    logger.info("Verificando directorios básicos de la aplicación")
    settings.LOG_DIR.mkdir(exist_ok=True, parents=True)


def save_agent_resources(
    agent_name: str, port: int, resources: Dict[str, Any], agent_id: str = None
) -> str:
    """
    Guarda los recursos del agente en un archivo JSON.

    Args:
        agent_name (str): Nombre del agente
        port (int): Puerto del servicio
        resources (Dict): Recursos a guardar
        agent_id (str, optional): ID del agente para incluir en los recursos

    Returns:
        str: Ruta al archivo de recursos creado
    """
    # Mapa de puertos fijos para cada agente
    agent_ports = {"vfs": 8001, "kendra": 8002, "gpt4": 8003, "orchestrator": 8004}

    # Usar el puerto fijo del agente si está definido
    actual_port = agent_ports.get(agent_name, port)

    # Ruta de la carpeta y ruta del fichero
    agent_dir = settings.AGENTS_DIR / agent_name
    resources_file = agent_dir / f"manifest_resources_{actual_port}.json"

    # Incluir el ID del agente en los recursos para referencia
    resources_to_save = resources.copy() if resources else {}

    # Si se proporciona un ID de agente, incluirlo en los recursos
    if agent_id:
        resources_to_save["agent_id"] = agent_id

    # También guardar el nombre del agente para referencia
    resources_to_save["agent_name"] = agent_name

    # Intenta guardar el fichero en la ruta y lo devuelve el la respuesta
    try:
        with open(resources_file, "w") as f:
            json.dump(resources_to_save, f, indent=2)

        logger.debug(
            "Recursos guardados para %s en puerto %s: %s",
            agent_name,
            actual_port,
            resources_file,
        )
        return str(resources_file)
    except Exception as e:
        logger.error("Error al guardar recursos del agente %s: %s", agent_name, str(e))
        raise IOError(f"Error al guardar recursos del agente: {str(e)}")


def clean_agent_resources(agent_name: str, port: int) -> bool:
    """
    Elimina el fichero resources de la carpeta del respectivo agente cuando se elimina
    el microservicio asociado.

    Args:
        agent_name (str): Nombre del agente
        port (int): Puerto del servicio

    Returns:
        bool: True si se eliminó correctamente, False si no existía o hubo un error
    """
    # Mapa de puertos fijos para cada agente
    agent_ports = {"vfs": 8001, "kendra": 8002, "gpt4": 8003, "orchestrator": 8004}

    # Usar el puerto fijo del agente si está definido
    actual_port = agent_ports.get(agent_name, port)

    try:
        resources_file = (
            settings.AGENTS_DIR / agent_name / f"manifest_resources_{actual_port}.json"
        )

        if resources_file.exists():
            resources_file.unlink()
            logger.debug(
                "Recursos eliminados para %s en puerto %s", agent_name, actual_port
            )
            return True

        logger.debug(
            "No se encontraron recursos para %s en puerto %s", agent_name, actual_port
        )
        return False
    except Exception as e:
        logger.error("Error al eliminar recursos del agente %s: %s", agent_name, e)
        return False


def get_agent_fixed_port(agent_name: str) -> int:
    """
    Obtiene el puerto fijo asignado a un agente específico.

    Args:
        agent_name (str): Nombre del agente

    Returns:
        int: Puerto fijo asignado al agente
    """
    agent_ports = {"vfs": 8001, "kendra": 8002, "gpt4": 8003, "orchestrator": 8004}

    return agent_ports.get(agent_name, 0)


def generate_agent_command(agent_name: str, _: int) -> List[str]:
    """
    Genera el comando para ejecutar el agente directamente desde su ubicación.

    Args:
        agent_name (str): Nombre del agente
        port (int): Puerto pasado para registros internos (no se usa en la inicialización)

    Returns:
        List[str]: Comando para iniciar el servicio

    Raises:
        IOError: Si no se encuentra el archivo asgi.py del agente
    """

    # Determina la ruta del archivo asgi.py del agente
    agent_asgi_file = settings.AGENTS_DIR / agent_name / "asgi.py"

    # Verifica que exista el fichero asgi del agente
    if not agent_asgi_file.exists():
        logger.error("No se encontró el archivo asgi.py para el agente %s", agent_name)
        raise IOError(f"No se encontró el archivo asgi.py para el agente {agent_name}")

    # Devuelve el comando para ejecutar el agente directamente
    # (el puerto está codificado dentro del archivo asgi.py)
    return [sys.executable, str(agent_asgi_file)]
