import os
from pydantic_settings import BaseSettings
from pathlib import Path
from loguru import logger
import sys


# Obtiene el directorio base del proyecto
BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    """
    Configuración centralizada de la aplicación utilizando Pydantic BaseSettings.

    Esta clase gestiona todos los parámetros configurables del sistema, incluyendo:
    - Configuración general (nombre de la aplicación, modo debug)
    - Rangos de puertos para la API principal y los servicios de agentes
    - Rutas de archivos y directorios para datos persistentes
    - Timeouts y otros parámetros operativos

    Los valores se cargan con el siguiente orden de prioridad:
    1. Variables de entorno
    2. Archivo .env
    3. Valores predeterminados definidos en la clase
    """

    # Configuración general
    APP_NAME: str = "Generative AI Agent Manager"
    DEBUG: bool = os.getenv("DEBUG", "False").lower() == "true"
    VERSION: str = "0.1.0"

    # Configuración de puertos. 8000 para el servicio principal
    PORT: int = int(os.getenv("PORT", "8000"))
    MIN_AGENT_PORT: int = 8001
    MAX_AGENT_PORT: int = 12001

    # Directorios y archivos
    AGENTS_DIR: Path = BASE_DIR / "agents"
    LOG_DIR: Path = BASE_DIR / "logs"

    # Configuración de agentes (iniciar y cerrar)
    AGENT_STARTUP_TIMEOUT: int = 30
    AGENT_SHUTDOWN_TIMEOUT: int = 30

    # Configuración de logging
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO").upper()
    LOG_FORMAT: str = (
        "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
    )
    LOG_RETENTION: str = "7 days"
    LOG_ROTATION: str = "500 MB"

    # Clase añadida que configura el comportamiento de Pydantic para env
    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()  # Instancia la configuración


# Elimina el logger predeterminado de FastAPI
logger.remove()

# Añade el logger loguru por consola con la configuración anterior
logger.add(
    sys.stderr,
    format=settings.LOG_FORMAT,
    level=settings.LOG_LEVEL,
    colorize=True,
)

# Almacena el logger en un fichero por cada ejecución en la carpeta logs
settings.LOG_DIR.mkdir(exist_ok=True, parents=True)

logger.add(
    settings.LOG_DIR / "app_{time}.log",
    rotation=settings.LOG_ROTATION,
    retention=settings.LOG_RETENTION,
    format=settings.LOG_FORMAT,
    level=settings.LOG_LEVEL,
    compression="zip",
)


app_logger = logger  # Exporta el logger configurado
