from fastapi import FastAPI
from contextlib import asynccontextmanager
from .api import router as api_router
from .config import settings, app_logger as logger
from .utils import ensure_directories
from .services import agent_manager


@asynccontextmanager
async def lifespan(_: FastAPI):
    """
    Manejador del ciclo de vida de la aplicación.

    Se ejecuta al iniciar y detener la aplicación:
    - Al iniciar: Asegura que exista la carpeta de logs
    - Al detener: Detiene todos los agentes en ejecución
    """

    # Código que se ejecuta al iniciar la aplicación
    logger.info(
        "%s v%s iniciado en el puerto %s",
        settings.APP_NAME,
        settings.VERSION,
        settings.PORT,
    )
    ensure_directories()

    # Cede el control a la aplicación
    yield

    # Código que se ejecuta al cerrar la aplicación
    logger.info("Deteniendo todos los agentes activos...")
    await agent_manager.stop_all_agents()
    logger.info("Aplicación cerrada correctamente")


# Crea la aplicación y registra las rutas
app = FastAPI(
    title=settings.APP_NAME,
    description="API para gestionar agentes de IA generativa como microservicios",
    version=settings.VERSION,
    lifespan=lifespan,
)

app.include_router(api_router, prefix="/api")
